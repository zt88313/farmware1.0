package com.example.farmware.offlinebase.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.farmware.offlinebase.entities.BestSoldItemWithName
import com.example.farmware.offlinebase.entities.TradeHistoryItemEntity

@Dao
interface TradeHistoryItemDao {

    @Insert
    suspend fun insert(item: TradeHistoryItemEntity): Long

    @Query("SELECT * FROM trade_history_item")
    suspend fun getAll(): List<TradeHistoryItemEntity>

    @Query("SELECT * FROM trade_history_item WHERE trade_history_item_id = :id")
    suspend fun getById(id: Int): TradeHistoryItemEntity?

    @Query("SELECT * FROM trade_history_item WHERE trade_history_id = :historyId")
    suspend fun getByHistoryId(historyId: Int): List<TradeHistoryItemEntity>

    @Update
    suspend fun update(item: TradeHistoryItemEntity)

    @Query("DELETE FROM trade_history_item WHERE trade_history_item_id = :id")
    suspend fun deleteById(id: Int)

    @Query("""
      WITH sold AS (
        SELECT
          item_type,
          item_id,
          SUM(quantity * price) AS revenue
        FROM trade_history_item
        WHERE trade_history_id IN (
          SELECT trade_history_id
          FROM trade_history
          WHERE trade_type = 'sell'
        )
        GROUP BY item_type, item_id
      ),
      max_rev AS (
        SELECT MAX(revenue) AS value FROM sold
      )
      SELECT
        s.item_type,
        s.item_id,
        s.revenue,
        -- pick the name from the right table based on the discriminator
        COALESCE(
          p.product_name,
          sd.seed_name,
          m.miscellaneous_item_name,
          b.biochemical_item_name
        ) AS item_name
      FROM sold AS s
        LEFT JOIN product AS p
          ON s.item_type = 'product' AND p.product_id = s.item_id
        LEFT JOIN seed AS sd
          ON s.item_type = 'seed' AND sd.seed_id = s.item_id
        LEFT JOIN miscellaneous_item AS m
          ON s.item_type = 'miscellaneous_item' AND m.miscellaneous_item_id = s.item_id
        LEFT JOIN biochemical_item AS b
          ON s.item_type = 'biochemical_item' AND b.biochemical_item_id = s.item_id
      WHERE s.revenue = (SELECT value FROM max_rev)
    """)
    suspend fun getBestSoldItemsWithName(): List<BestSoldItemWithName>
}
