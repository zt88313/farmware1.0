// AdddataFormFragment.kt
package com.example.farmware.fragments.dataforms

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.farmware.LocalDatabase
import com.example.farmware.PrefsManager
import com.example.farmware.R
import com.example.farmware.apptools.EditableItem
import com.example.farmware.apptools.SelectedItemDataAdapter
import com.example.farmware.getFieldsForTable
import com.example.farmware.navigateToDatabaseBrowsing
import com.example.farmware.offlinebase.entities.*
import kotlinx.coroutines.launch
import android.widget.Button
import com.example.farmware.getCurrentDate

class AdddataFormFragment : Fragment() {
    private lateinit var columnsAdapter: SelectedItemDataAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ) = inflater.inflate(R.layout.fragment_adddata_form, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        columnsAdapter = SelectedItemDataAdapter(requireContext())
        view.findViewById<RecyclerView>(R.id.rv_datacolumns).apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = columnsAdapter
        }

        val db     = LocalDatabase.getDatabase(requireContext())
        var userId = PrefsManager.getLoggedInUserId(requireContext())
        val raw    = PrefsManager.getSelectedTable(requireContext())
        val table  = raw.lowercase().replace(' ', '_')


        // show hint
        lifecycleScope.launch {
            when (table) {
                "warehouse", "farming_field" -> {
                    // Fetch all farms belonging to the current user
                    userId  = PrefsManager.getLoggedInUserId(requireContext())
                    val farmIds = db.farmDao()
                        .getFarmsByUser(userId)
                        .map { it.farmId }
                        .joinToString(", ")

                    // Only farm_id gets a hint → stays editable
                    columnsAdapter.setHints(mapOf(
                        "farm_id" to if (farmIds.isEmpty())
                            "No farms (create one first)"
                        else
                            "Available: $farmIds"
                    ))

                    // Disable Save button until at least one farm exists
                    view.findViewById<Button>(R.id.btn_editdata_submit).isEnabled =
                        farmIds.isNotEmpty()
                }
                "trade_history" -> {
                    // Fetch available Trader and Warehouse IDs
                    val traderIds    = db.traderDao().getAll().map { it.traderId }.joinToString(", ")
                    val warehouseIds = db.warehouseDao().getAll().map { it.warehouseId }.joinToString(", ")

                    // Provide hints only for those two FKs
                    columnsAdapter.setHints(mapOf(
                        "trader_id"     to if (traderIds.isEmpty()) "No traders (create one first)"
                        else "Available: $traderIds",
                        "warehouse_id"  to if (warehouseIds.isEmpty()) "No warehouses (create one first)"
                        else "Available: $warehouseIds"
                    ))
                    // Disable Save button if either list is empty
                    view.findViewById<Button>(R.id.btn_editdata_submit).isEnabled =
                        traderIds.isNotEmpty() && warehouseIds.isNotEmpty()
                }
                "seed" -> {
                    // Gather all valid warehouse IDs
                    val warehouseIds = db.warehouseDao()
                        .getAll()
                        .map { it.warehouseId }
                        .joinToString(", ")

                    //  Only warehouse_id gets a hint—so it stays editable
                    columnsAdapter.setHints(mapOf(
                        "warehouse_id" to if (warehouseIds.isEmpty())
                            "No warehouses (create one first)"
                        else
                            "Available: $warehouseIds"
                    ))

                    //Disable Save if there are no warehouses at all
                    view.findViewById<Button>(R.id.btn_editdata_submit).isEnabled =
                        warehouseIds.isNotEmpty()
                }
                "product" -> {
                    // Gather valid Warehouse IDs
                    val warehouseIds = db.warehouseDao()
                        .getAll()
                        .map { it.warehouseId }
                        .joinToString(", ")

                    // Only warehouse_id gets a hint
                    columnsAdapter.setHints(mapOf(
                        "warehouse_id" to if (warehouseIds.isEmpty())
                            "No warehouses (create one first)"
                        else
                            "Available: $warehouseIds"
                    ))

                    // Disable Save until at least one warehouse exists
                    view.findViewById<Button>(R.id.btn_editdata_submit).isEnabled =
                        warehouseIds.isNotEmpty()
                }
                "miscellaneous_item" -> {
                    // Hint the warehouse_id field only
                    val whIds = db.warehouseDao().getAll().map { it.warehouseId }.joinToString(", ")
                    columnsAdapter.setHints(mapOf(
                        "warehouse_id" to if (whIds.isEmpty())
                            "No warehouses (create one first)"
                        else
                            "Available: $whIds"
                    ))
                    view.findViewById<Button>(R.id.btn_editdata_submit).isEnabled = whIds.isNotEmpty()
                }
                "biochemical_item" -> {
                    // Gather warehouse IDs
                    val whIds = db.warehouseDao().getAll().map { it.warehouseId }.joinToString(", ")
                    // Hint only the warehouse_id field
                    columnsAdapter.setHints(mapOf(
                        "warehouse_id" to if (whIds.isEmpty())
                            "No warehouses (create one first)"
                        else
                            "Available: $whIds"
                    ))
                    // Disable Save until at least one warehouse exists
                    view.findViewById<Button>(R.id.btn_editdata_submit).isEnabled = whIds.isNotEmpty()
                }
                "trade_history_item" -> {
                    // Fetch valid history IDs
                    val historyIds = db.tradeHistoryDao()
                        .getAll()
                        .map { it.tradeHistoryId }
                        .joinToString(", ")
                    // Short→full type map
                    val typeMap = mapOf(
                        "seed" to "seed",
                        "prod" to "product",
                        "misc" to "miscellaneous_item",
                        "bio"  to "biochemical_item"
                    )
                    // Provide concise hints for all fields
                    columnsAdapter.setHints(mapOf(
                        "trade_history_id" to if (historyIds.isEmpty())
                            "No history (create one first)"
                        else
                            "Hist#: $historyIds",
                        // only the short keys shown here
                        "item_type"        to "Type: ${typeMap.keys.joinToString("/")}",
                        "item_id"          to "Enter ID for chosen type"
                    ))
                    view.findViewById<Button>(R.id.btn_editdata_submit).isEnabled =
                        historyIds.isNotEmpty()
                }

                else -> {
                    columnsAdapter.setHints(emptyMap())
                }
            } // detail hint logics

            // Finally populate the rows for ANY table
            columnsAdapter.setItems(getFieldsForTable(table))
        }// hint logic



        view.findViewById<Button>(R.id.btn_editdata_submit).setOnClickListener {
            val edited = columnsAdapter.getEditedItems()
            lifecycleScope.launch {
                when (table) { //the add  data logics
                    "farm" -> {
                        val name = edited.find { it.key=="farm_name" }?.value.orEmpty()
                        val info = edited.find { it.key=="farm_info" }?.value.orEmpty()
                        val uid  = PrefsManager.getLoggedInUserId(requireContext())
                        if(name.isBlank()||info.isBlank()||uid<0) {
                            Toast.makeText(requireContext(),"Please enter farm name/info", Toast.LENGTH_SHORT).show()
                        } else {
                            db.farmDao().insert(FarmEntity(userId=uid, farmName=name, farmInfo=info))
                            navigateToDatabaseBrowsing(requireContext())
                        }
                    }
                    "warehouse" -> {
                        val fid  = edited.find{it.key=="farm_id"}?.value?.toIntOrNull()
                        val n    = edited.find{it.key=="warehouse_name"}?.value.orEmpty()
                        val cap  = edited.find{it.key=="warehouse_capacity"}?.value?.toIntOrNull()?:0
                        if(fid==null){
                            Toast.makeText(requireContext(),"Invalid Farm ID",Toast.LENGTH_SHORT).show()
                        } else if(db.farmDao().getFarmById(fid)==null){
                            Toast.makeText(requireContext(),"Farm not found",Toast.LENGTH_SHORT).show()
                        } else if(n.isBlank()||cap<=0){
                            Toast.makeText(requireContext(),"Please enter name & valid capacity",Toast.LENGTH_SHORT).show()
                        } else {
                            db.warehouseDao().insert(WarehouseEntity(
                                warehouseName=n, warehouseCapacity=cap, farmId=fid
                            ))
                            navigateToDatabaseBrowsing(requireContext())
                        }
                    }
                    "farming_field" -> {
                        val fid = edited.find{it.key=="farm_id"}?.value?.toIntOrNull()
                        val nm  = edited.find{it.key=="field_name"}?.value.orEmpty()
                        val tp  = edited.find{it.key=="field_type"}?.value.orEmpty()
                        if(fid==null){
                            Toast.makeText(requireContext(),"Invalid Farm ID",Toast.LENGTH_SHORT).show()
                        } else if(db.farmDao().getFarmById(fid)==null){
                            Toast.makeText(requireContext(),"Farm not found",Toast.LENGTH_SHORT).show()
                        } else if(nm.isBlank()||tp.isBlank()){
                            Toast.makeText(requireContext(),"Please enter name & type",Toast.LENGTH_SHORT).show()
                        } else {
                            db.farmingFieldDao().insert(FarmingFieldEntity(
                                fieldName=nm, fieldType=tp, farmId=fid
                            ))
                            navigateToDatabaseBrowsing(requireContext())
                        }
                    }
                    "trader" -> {
                        // pull raw values from your adapter
                        val edited = columnsAdapter.getEditedItems()
                        val name        = edited.find { it.key=="trader_name" }?.value.orEmpty()
                        val type        = edited.find { it.key=="trader_type" }?.value.orEmpty()
                        val email       = edited.find { it.key=="trader_email" }?.value.orEmpty()
                        val contact     = edited.find { it.key=="trader_contact" }?.value.orEmpty()
                        val description = edited.find { it.key=="trader_description" }?.value.orEmpty()

                        // basic validation
                        if (name.isBlank() || type.isBlank() || email.isBlank()) {
                            Toast.makeText(
                                requireContext(),
                                "Please enter at least name, type, and email",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            // insert into DB and go back
                            db.traderDao().insert(
                                TraderEntity(
                                    traderName        = name,
                                    traderType        = type,
                                    traderEmail       = email,
                                    traderContact     = contact,
                                    traderDescription = description
                                )
                            )
                            navigateToDatabaseBrowsing(requireContext())
                        }
                    }
                    "trade_history" -> {
                        // pull the FK values
                        val edited      = columnsAdapter.getEditedItems().associate { it.key to it.value }
                        val traderId    = edited["trader_id"]?.toIntOrNull()    ?: 0
                        val warehouseId = edited["warehouse_id"]?.toIntOrNull() ?: 0

                        val date        = getCurrentDate()//get a date
                        val type        = edited["trade_type"].orEmpty()

                        // validate trader & warehouse exist, and that type is filled
                        val traderExists = db.traderDao().getById(traderId) != null
                        val warehouse    = db.warehouseDao().getWarehouseById(warehouseId)

                        when {
                            !traderExists ->
                                Toast.makeText(requireContext(),
                                    "Trader ID not found", Toast.LENGTH_SHORT).show()

                            warehouse == null ->
                                Toast.makeText(requireContext(),
                                    "Warehouse ID not found", Toast.LENGTH_SHORT).show()

                            type.isBlank() ->
                                Toast.makeText(requireContext(),
                                    "Please fill in type", Toast.LENGTH_SHORT).show()

                            else -> {
                                // derive farmId
                                val farmId = warehouse.farmId
                                // insert with today’s date
                                db.tradeHistoryDao().insert(
                                    TradeHistoryEntity(
                                        traderId    = traderId,
                                        farmId      = farmId,
                                        warehouseId = warehouseId,
                                        tradeDate   = date,      // now set to current date
                                        tradeType   = type
                                    )
                                )
                                navigateToDatabaseBrowsing(requireContext())
                            }
                        }
                    }
                    "seed" -> {
                        val edited      = columnsAdapter.getEditedItems().associate { it.key to it.value }
                        val warehouseId = edited["warehouse_id"]?.toIntOrNull() ?: 0
                        val name        = edited["seed_name"].orEmpty()
                        val unit        = edited["seed_unit"].orEmpty()
                        val quantity    = edited["seed_quantity"]?.toIntOrNull() ?: 0

                        val warehouse    = db.warehouseDao().getWarehouseById(warehouseId)

                        // basic validation
                        if (warehouse == null) {
                            Toast.makeText(requireContext(),
                                "Please enter a valid Warehouse ID",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else if (name.isBlank() || unit.isBlank() || quantity <= 0) {
                            Toast.makeText(requireContext(),
                                "Please fill in name, unit, and a positive quantity",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            // insert into DB
                            db.seedDao().insert(
                                SeedEntity(
                                    warehouseId = warehouseId,
                                    seedName    = name,
                                    seedUnit    = unit,
                                    seedQuantity= quantity
                                )
                            )
                            navigateToDatabaseBrowsing(requireContext())
                        }
                    }
                    "product" -> {
                        val edited      = columnsAdapter.getEditedItems().associate { it.key to it.value }
                        val warehouseId = edited["warehouse_id"]?.toIntOrNull()   ?: 0
                        val name        = edited["product_name"].orEmpty()
                        val unit        = edited["product_unit"].orEmpty()
                        val quantity    = edited["product_quantity"]?.toIntOrNull() ?: 0

                        val warehouse    = db.warehouseDao().getWarehouseById(warehouseId)

                        // basic validation
                        if (warehouse == null) {
                            Toast.makeText(
                                requireContext(),
                                "Please enter a valid Warehouse ID",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else if (name.isBlank() || unit.isBlank() || quantity <= 0) {
                            Toast.makeText(
                                requireContext(),
                                "Please fill in name, unit, and a positive quantity",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            // insert into DB
                            db.productDao().insert(
                                ProductEntity(
                                    warehouseId    = warehouseId,
                                    productName    = name,
                                    productUnit    = unit,
                                    productQuantity= quantity
                                )
                            )
                            navigateToDatabaseBrowsing(requireContext())
                        }
                    }
                    "miscellaneous_item" -> {
                        val e    = columnsAdapter.getEditedItems().associate { it.key to it.value }
                        val wid  = e["warehouse_id"]?.toIntOrNull()           ?: 0
                        val name = e["miscellaneous_item_name"].orEmpty()
                        val desc = e["miscellaneous_item_description"].orEmpty()
                        val unit = e["miscellaneous_item_unit"].orEmpty()
                        val qty  = e["miscellaneous_item_quantity"]?.toIntOrNull() ?: 0

                        val warehouse    = db.warehouseDao().getWarehouseById(wid)

                        if (warehouse == null) {
                            Toast.makeText(requireContext(),"Invalid Warehouse ID",Toast.LENGTH_SHORT).show()
                        } else if (name.isBlank()||desc.isBlank()||unit.isBlank()||qty<=0) {
                            Toast.makeText(requireContext(),"Fill all fields with valid values",Toast.LENGTH_SHORT).show()
                        } else {
                            db.miscellaneousItemDao().insert(
                                MiscellaneousItemEntity(
                                    warehouseId      = wid,
                                    itemName         = name,
                                    itemDescription  = desc,
                                    itemUnit         = unit,
                                    itemQuantity     = qty
                                )
                            )
                            navigateToDatabaseBrowsing(requireContext())
                        }
                    }
                    "biochemical_item" -> {
                        val e    = columnsAdapter.getEditedItems().associate { it.key to it.value }
                        val wid  = e["warehouse_id"]?.toIntOrNull() ?: 0
                        val name = e["biochemical_item_name"].orEmpty()
                        val desc = e["biochemical_item_description"].orEmpty()
                        val unit = e["biochemical_item_unit"].orEmpty()
                        val qty  = e["biochemical_item_quantity"]?.toIntOrNull() ?: 0

                        val warehouse    = db.warehouseDao().getWarehouseById(wid)

                        if (warehouse == null) {
                            Toast.makeText(requireContext(),"Invalid Warehouse ID",Toast.LENGTH_SHORT).show()
                        } else if (name.isBlank()||desc.isBlank()||unit.isBlank()||qty<=0) {
                            Toast.makeText(requireContext(),"Fill all fields with valid values",Toast.LENGTH_SHORT).show()
                        } else {
                            db.biochemicalItemDao().insert(
                                BiochemicalItemEntity(
                                    warehouseId       = wid,
                                    itemName          = name,
                                    itemDescription   = desc,
                                    itemUnit          = unit,
                                    itemQuantity      = qty
                                )
                            )
                            navigateToDatabaseBrowsing(requireContext())
                        }
                    }
                    "trade_history_item" -> {
                        val e          = columnsAdapter.getEditedItems().associate { it.key to it.value }
                        val histId     = e["trade_history_id"]?.toIntOrNull() ?: 0
                        // Map short input to full type
                        val shortType  = e["item_type"]?.trim()?.lowercase().orEmpty()
                        val typeMap    = mapOf(
                            "seed" to "seed",
                            "prod" to "product",
                            "misc" to "miscellaneous_item",
                            "bio"  to "biochemical_item"
                        )
                        val fullType   = typeMap[shortType]
                        if (fullType == null) {
                            Toast.makeText(
                                requireContext(),
                                "Type must be one of: ${typeMap.keys.joinToString(", ")}",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        val itemId     = e["item_id"]?.toIntOrNull() ?: 0
                        val qty        = e["quantity"]?.toIntOrNull() ?: 0
                        val price      = e["price"]?.toDoubleOrNull() ?: -1.0
                        // Validate FKs and inputs
                        if (db.tradeHistoryDao().getById(histId) == null) {
                            Toast.makeText(requireContext(), "Trade History ID not found", Toast.LENGTH_SHORT).show()
                            return@launch
                        }
                        val exists = when (fullType) {
                            "seed"               -> db.seedDao().getById(itemId) != null
                            "product"            -> db.productDao().getById(itemId) != null
                            "miscellaneous_item" -> db.miscellaneousItemDao().getById(itemId) != null
                            "biochemical_item"   -> db.biochemicalItemDao().getById(itemId) != null
                            else                 -> false
                        }
                        if (!exists) {
                            Toast.makeText(
                                requireContext(),
                                "No $fullType found with ID $itemId",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        if (qty <= 0 || price < 0.0) {
                            Toast.makeText(
                                requireContext(),
                                "Enter a positive quantity and non-negative price",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        //Insert with the full type
                        db.tradeHistoryItemDao().insert(
                            TradeHistoryItemEntity(
                                tradeHistoryId = histId,
                                itemType       = fullType,
                                itemId         = itemId,
                                quantity       = qty,
                                price          = price
                            )
                        )
                        navigateToDatabaseBrowsing(requireContext())
                    }

                } // when(table)...(the detail add new logics)
            }
        }

        view.findViewById<Button>(R.id.btn_editdata_cancel).setOnClickListener {
            navigateToDatabaseBrowsing(requireContext())
        }
    }
}
