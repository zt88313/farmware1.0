package com.example.farmware.offlinebase.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trade_history")
data class TradeHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "trade_history_id")
    val tradeHistoryId: Int = 0,

    @ColumnInfo(name = "trader_id")
    val traderId: Int,

    @ColumnInfo(name = "farm_id")
    val farmId: Int,

    @ColumnInfo(name = "warehouse_id")
    val warehouseId: Int,

    @ColumnInfo(name = "trade_date")
    val tradeDate: String,

    @ColumnInfo(name = "trade_type")
    val tradeType: String
)
