package com.example.farmware.offlinebase.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.farmware.offlinebase.entities.TraderEntity

@Dao
interface TraderDao {

    @Insert
    suspend fun insert(trader: TraderEntity): Long

    @Query("SELECT * FROM trader")
    suspend fun getAll(): List<TraderEntity>

    @Query("SELECT * FROM trader WHERE trader_id = :id")
    suspend fun getById(id: Int): TraderEntity?

    @Query("SELECT * FROM trader WHERE trader_name = :name")
    suspend fun getByName(name: String): List<TraderEntity>

    @Update
    suspend fun update(trader: TraderEntity)

    @Query("DELETE FROM trader WHERE trader_id = :id")
    suspend fun deleteById(id: Int)
}
