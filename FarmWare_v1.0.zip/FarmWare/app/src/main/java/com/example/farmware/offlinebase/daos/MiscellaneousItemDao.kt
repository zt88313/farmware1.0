package com.example.farmware.offlinebase.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.farmware.offlinebase.entities.MiscellaneousItemEntity

@Dao
interface MiscellaneousItemDao {

    @Insert
    suspend fun insert(item: MiscellaneousItemEntity): Long

    @Query("SELECT * FROM miscellaneous_item")
    suspend fun getAll(): List<MiscellaneousItemEntity>

    @Query("SELECT * FROM miscellaneous_item WHERE miscellaneous_item_id = :id")
    suspend fun getById(id: Int): MiscellaneousItemEntity?

    @Query("SELECT * FROM miscellaneous_item WHERE warehouse_id = :warehouseId")
    suspend fun getByWarehouse(warehouseId: Int): List<MiscellaneousItemEntity>

    @Update
    suspend fun update(item: MiscellaneousItemEntity)

    @Query("DELETE FROM miscellaneous_item WHERE miscellaneous_item_id = :id")
    suspend fun deleteById(id: Int)
}
