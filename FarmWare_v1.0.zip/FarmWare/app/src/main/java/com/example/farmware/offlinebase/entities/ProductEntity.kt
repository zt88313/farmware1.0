package com.example.farmware.offlinebase.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "product")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "product_id")
    val productId: Int = 0,

    @ColumnInfo(name = "warehouse_id")
    val warehouseId: Int,

    @ColumnInfo(name = "product_name")
    val productName: String,

    @ColumnInfo(name = "product_unit")
    val productUnit: String,

    @ColumnInfo(name = "product_quantity")
    val productQuantity: Int
)

//data class for report shown
data class ProductNameQuantity(
    @ColumnInfo(name = "product_name") val productName: String,
    @ColumnInfo(name = "product_quantity") val productQuantity: Int
)