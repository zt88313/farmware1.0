package com.example.farmware

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.example.farmware.fragments.BrowsingReportFragment
import com.example.farmware.fragments.FeedbackFragment
import com.example.farmware.fragments.dataforms.UserProfileFragment
import com.example.farmware.fragments.dataforms.EditdataFormFragment

class DataFormActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_data_form)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val fragmentType = intent.getStringExtra("fragment_type") ?: "editData"  // default to editData
        val itemId = intent.getIntExtra("item_id", -1)

        // Load the appropriate fragment based on fragmentType
        when (fragmentType) {
            "editData" -> {
                loadFragment(EditdataFormFragment(), itemId)
            }
            "editReport" -> {
                //loadFragment(EditReportCriteriaFormFragment(), itemId)
            }
            "addData" -> {
                loadFragment(com.example.farmware.fragments.dataforms.AdddataFormFragment(), itemId)
            }
            "editProfile"    -> loadFragment(UserProfileFragment(), itemId)
            "feedback" -> {loadFragment(FeedbackFragment(), itemId) }
            "browsingReport" -> {loadFragment(BrowsingReportFragment(), itemId) }
        }

    }



    private fun loadFragment(fragment: Fragment, itemId: Int) {
        val bundle = Bundle()
        bundle.putInt("item_id", itemId)
        fragment.arguments = bundle

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container_dataform, fragment)
            .commit()
    }

}