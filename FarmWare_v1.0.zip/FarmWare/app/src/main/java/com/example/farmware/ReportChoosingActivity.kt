package com.example.farmware

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.farmware.fragments.BrowsingReportFragment

class ReportChoosingActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_report_choosing)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Find views
        val btnReport1 = findViewById<Button>(R.id.btn_repo_1)
        val btnReport2 = findViewById<Button>(R.id.btn_repo_2)
        val btnReport3 = findViewById<Button>(R.id.btn_repo_3)
        val btnBack    = findViewById<ImageButton>(R.id.ibtn_back_report_choose)

        // Click listeners
        btnReport1.setOnClickListener {
            Toast.makeText(this, "Show product information", Toast.LENGTH_SHORT).show()
            JumpToBrowsingReport(1)
        }

        btnReport2.setOnClickListener {
            Toast.makeText(this, "Show seeds low storage warning", Toast.LENGTH_SHORT).show()
            JumpToBrowsingReport(2)
        }

        btnReport3.setOnClickListener {
            Toast.makeText(this, "Show best sold item", Toast.LENGTH_SHORT).show()
            JumpToBrowsingReport(3)
        }

        btnBack.setOnClickListener {
            jumpToHomePage(this)
        }
    }

    private fun JumpToBrowsingReport(reportId : Int){
        jumpToDataform(this,reportId,"browsingReport")
    }



}