package com.example.farmware.offlinebase.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.farmware.offlinebase.entities.ProductEntity
import com.example.farmware.offlinebase.entities.ProductNameQuantity

@Dao
interface ProductDao {

    @Insert
    suspend fun insert(product: ProductEntity): Long

    @Query("SELECT * FROM product")
    suspend fun getAll(): List<ProductEntity>

    @Query("SELECT * FROM product WHERE product_id = :id")
    suspend fun getById(id: Int): ProductEntity?

    @Query("SELECT * FROM product WHERE warehouse_id = :warehouseId")
    suspend fun getByWarehouse(warehouseId: Int): List<ProductEntity>

    @Update
    suspend fun update(product: ProductEntity)

    @Query("DELETE FROM product WHERE product_id = :id")
    suspend fun deleteById(id: Int)

    //count sum items number
    @Query("SELECT COUNT(*) FROM product")
    suspend fun getProductCount(): Int

    //out put which items max stored
    @Query("""
      SELECT 
        product_name ,
        product_quantity 
      FROM product
      WHERE product_quantity = (
        SELECT MAX(product_quantity) FROM product
      )
    """)
    suspend fun getMaxQuantityItems(): List<ProductNameQuantity>
}
