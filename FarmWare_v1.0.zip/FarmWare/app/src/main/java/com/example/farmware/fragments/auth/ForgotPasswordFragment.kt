package com.example.farmware.fragments.auth


import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.farmware.LocalDatabase
import com.example.farmware.LoginActivity
import com.example.farmware.MANAGER_EMAIL
import com.example.farmware.PrefsManager
import com.example.farmware.R
import com.example.farmware.encryptPassword
import com.example.farmware.sendForgotPasswordEmail
import kotlinx.coroutines.launch

class ForgotPasswordFragment : Fragment(R.layout.fragment_forgot_password) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etUsername = view.findViewById<EditText>(R.id.et_fp_username)
        val btnSubmit  = view.findViewById<Button>(R.id.btn_fp_submit)
        val btnBack   = view.findViewById<ImageButton>(R.id.ibtn_fp_back)

        btnSubmit.setOnClickListener {
            val username = etUsername.text.toString().trim()
            if (username.isEmpty()) {
                Toast.makeText(requireContext(), "Please enter your username", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // enforce daily limit
            val used = PrefsManager.getForgotCount(requireContext())
            if (used >= 3) {
                Toast.makeText(requireContext(),
                    "You have reached today's limit", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                // lookup user
                val user = LocalDatabase.getDatabase(requireContext())
                    .userDao().getUserByUsername(username)
                if (user == null) {
                    Toast.makeText(requireContext(),
                        "No such user found", Toast.LENGTH_SHORT).show()
                } else {
                    // encrypt and send
                    val encrypted = encryptPassword(user.userPassword)
                    val subject   = "Forgot Password: $username"
                    val body      = "Encrypted password:\n$encrypted"
                    sendForgotPasswordEmail(requireContext(),
                        MANAGER_EMAIL, subject, body)

                    // increment and inform
                    PrefsManager.incrementForgotCount(requireContext())
                    Toast.makeText(requireContext(),
                        "Email intent launched", Toast.LENGTH_SHORT).show()

                    (activity as? LoginActivity)?.showLoginFragment()
                }
            }
        }

        btnBack.setOnClickListener {
            (activity as? LoginActivity)?.showLoginFragment()
        }
    }
}