package com.example.farmware.offlinebase.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "warehouse",
    foreignKeys = [
        ForeignKey(
            entity = FarmEntity::class,
            parentColumns = ["farm_id"],
            childColumns = ["farm_id"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class WarehouseEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "warehouse_id")
    val warehouseId: Int = 0,

    @ColumnInfo(name = "warehouse_name")
    val warehouseName: String,

    @ColumnInfo(name = "warehouse_capacity")
    val warehouseCapacity: Int,

    @ColumnInfo(name = "farm_id")
    val farmId: Int
)
