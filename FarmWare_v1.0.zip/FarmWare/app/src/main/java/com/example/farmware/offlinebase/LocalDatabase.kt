package com.example.farmware

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.farmware.offlinebase.daos.*
import com.example.farmware.offlinebase.entities.*


@Database(
    entities = [
        UserEntity::class,
        FarmEntity::class,
        WarehouseEntity::class,
        FarmingFieldEntity::class,
        TraderEntity::class,
        TradeHistoryEntity::class,
        SeedEntity::class,
        ProductEntity::class,
        MiscellaneousItemEntity::class,
        BiochemicalItemEntity::class,
        TradeHistoryItemEntity::class
    ],
    version = 11  // bump if columns/tables changed
)
abstract class LocalDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun farmDao(): FarmDao
    abstract fun warehouseDao(): WarehouseDao
    abstract fun farmingFieldDao(): FarmingFieldDao
    abstract fun traderDao(): TraderDao
    abstract fun tradeHistoryDao(): TradeHistoryDao
    abstract fun seedDao(): SeedDao
    abstract fun productDao(): ProductDao
    abstract fun miscellaneousItemDao(): MiscellaneousItemDao
    abstract fun biochemicalItemDao(): BiochemicalItemDao
    abstract fun tradeHistoryItemDao(): TradeHistoryItemDao

    companion object {
        @Volatile private var INSTANCE: LocalDatabase? = null

        fun getDatabase(context: Context): LocalDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LocalDatabase::class.java,
                    "local_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()

                INSTANCE = instance
                instance
            }
        }
    }
}
