package com.example.farmware.offlinebase.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.farmware.offlinebase.entities.SeedEntity

@Dao
interface SeedDao {

    @Insert
    suspend fun insert(seed: SeedEntity): Long

    @Query("SELECT * FROM seed")
    suspend fun getAll(): List<SeedEntity>

    @Query("SELECT * FROM seed WHERE seed_id = :id")
    suspend fun getById(id: Int): SeedEntity?

    @Query("SELECT * FROM seed WHERE warehouse_id = :warehouseId")
    suspend fun getByWarehouse(warehouseId: Int): List<SeedEntity>

    @Update
    suspend fun update(seed: SeedEntity)

    @Query("DELETE FROM seed WHERE seed_id = :id")
    suspend fun deleteById(id: Int)

    @Query("""
        SELECT *
        FROM seed
        WHERE seed_quantity = (
          SELECT MIN(seed_quantity)
          FROM seed
        )
    """)
    suspend fun getSeedsWithLowestQuantity(): List<SeedEntity>


}
