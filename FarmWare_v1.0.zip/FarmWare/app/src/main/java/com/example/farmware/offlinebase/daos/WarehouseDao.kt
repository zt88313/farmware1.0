package com.example.farmware.offlinebase.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.farmware.offlinebase.entities.WarehouseEntity

@Dao
interface WarehouseDao {
    @Insert
    suspend fun insert(warehouse: WarehouseEntity): Long

    @Query("SELECT * FROM warehouse")
    suspend fun getAll(): List<WarehouseEntity>

    @Query("SELECT * FROM warehouse WHERE farm_id = :farmId")
    suspend fun getWarehousesByFarm(farmId: Int): List<WarehouseEntity>

    @Query("SELECT * FROM warehouse WHERE warehouse_id = :id")
    suspend fun getWarehouseById(id: Int): WarehouseEntity?

    @Update
    suspend fun updateWarehouse(warehouse: WarehouseEntity)

    @Query("DELETE FROM warehouse WHERE warehouse_id = :id")
    suspend fun deleteById(id: Int)

    @Query("""
      SELECT w.* 
        FROM warehouse AS w
        JOIN farm      AS f  ON w.farm_id = f.farm_id
       WHERE f.user_id = :userId
    """)
    suspend fun getWarehousesByUser(userId: Int): List<WarehouseEntity>
}
