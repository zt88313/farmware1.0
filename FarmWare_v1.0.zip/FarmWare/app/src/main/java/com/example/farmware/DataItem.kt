package com.example.farmware

data class DataItem(
    val id: Int,
    val name: String,
    val info: String // this will be short description (like location, type, etc.)
)
