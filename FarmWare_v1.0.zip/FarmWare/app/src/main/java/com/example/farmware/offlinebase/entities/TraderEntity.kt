package com.example.farmware.offlinebase.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trader")
data class TraderEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "trader_id")
    val traderId: Int = 0,

    @ColumnInfo(name = "trader_name")
    val traderName: String,

    @ColumnInfo(name = "trader_type")
    val traderType: String,

    @ColumnInfo(name = "trader_email")
    val traderEmail: String,

    @ColumnInfo(name = "trader_contact")
    val traderContact: String,

    @ColumnInfo(name = "trader_description")
    val traderDescription: String
)
