package com.example.farmware.offlinebase.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.farmware.offlinebase.entities.FarmingFieldEntity

@Dao
interface FarmingFieldDao {
    @Insert
    suspend fun insert(field: FarmingFieldEntity): Long

    @Update
    suspend fun updateField(field: FarmingFieldEntity)

    @Query("SELECT * FROM FarmingFieldEntity")
    suspend fun getAll(): List<FarmingFieldEntity>

    @Query("SELECT * FROM FarmingFieldEntity WHERE farm_id = :farmId")
    suspend fun getFieldsByFarm(farmId: Int): List<FarmingFieldEntity>

    @Query("SELECT * FROM FarmingFieldEntity WHERE field_id = :id")
    suspend fun getFieldById(id: Int): FarmingFieldEntity?

    @Query("DELETE FROM FarmingFieldEntity WHERE field_id = :id")
    suspend fun deleteById(id: Int)

    @Query("""
      SELECT ff.* 
        FROM FarmingFieldEntity AS ff
        JOIN farm                AS f  ON ff.farm_id = f.farm_id
       WHERE f.user_id = :userId
    """)
    suspend fun getFieldsByUser(userId: Int): List<FarmingFieldEntity>
}
