package com.example.farmware.offlinebase.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trade_history_item")
data class TradeHistoryItemEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "trade_history_item_id")
    val tradeHistoryItemId: Int = 0,

    @ColumnInfo(name = "trade_history_id")
    val tradeHistoryId: Int,

    // discriminator: "seed", "product", "miscellaneous_item", or "biochemical_item"
    @ColumnInfo(name = "item_type")
    val itemType: String,

    // the PK of the actual item in its table
    @ColumnInfo(name = "item_id")
    val itemId: Int,

    @ColumnInfo(name = "quantity")
    val quantity: Int,

    @ColumnInfo(name = "price")
    val price: Double
)