package com.example.farmware.offlinebase.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "seed")
data class SeedEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "seed_id")
    val seedId: Int = 0,

    @ColumnInfo(name = "warehouse_id")
    val warehouseId: Int,

    @ColumnInfo(name = "seed_name")
    val seedName: String,

    @ColumnInfo(name = "seed_unit")
    val seedUnit: String,

    @ColumnInfo(name = "seed_quantity")
    val seedQuantity: Int
)
