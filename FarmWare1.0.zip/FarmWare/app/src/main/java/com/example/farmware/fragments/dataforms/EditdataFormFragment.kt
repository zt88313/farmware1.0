// EditdataFormFragment.kt
package com.example.farmware.fragments.dataforms

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.farmware.LocalDatabase
import com.example.farmware.PrefsManager
import com.example.farmware.R
import com.example.farmware.apptools.EditableItem
import com.example.farmware.apptools.SelectedItemDataAdapter
import com.example.farmware.getFieldsForTable
import com.example.farmware.navigateToDatabaseBrowsing
import com.example.farmware.offlinebase.entities.*
import kotlinx.coroutines.launch
import android.widget.Button

class EditdataFormFragment : Fragment() {
    private lateinit var columnsAdapter: SelectedItemDataAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ) = inflater.inflate(R.layout.fragment_editdata_form, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        columnsAdapter = SelectedItemDataAdapter(requireContext())
        view.findViewById<RecyclerView>(R.id.rv_datacolumns).apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = columnsAdapter
        }

        val db     = LocalDatabase.getDatabase(requireContext())
        val userId = PrefsManager.getLoggedInUserId(requireContext())
        val raw    = PrefsManager.getSelectedTable(requireContext())
        val table  = raw.lowercase().replace(' ', '_')
        val itemId = arguments?.getInt("item_id") ?: return

        lifecycleScope.launch {
            // hints for edit
            when (table) {
                "warehouse", "farming_field" -> {
                    val farms = db.farmDao().getFarmsByUser(userId)
                    val hint  = if (farms.isEmpty())
                        "No farms (create one first)"
                    else
                        "Available: ${farms.joinToString { it.farmId.toString() }}"
                    columnsAdapter.setHints(mapOf("farm_id" to hint))
                }
                "seed", "product", "miscellaneous_item", "biochemical_item" -> {
                    val whs  = db.warehouseDao().getAll().map { it.warehouseId }
                    val hint = if (whs.isEmpty())
                        "No warehouses (create one first)"
                    else
                        "Available: ${whs.joinToString()}"
                    columnsAdapter.setHints(mapOf("warehouse_id" to hint))
                }
                "trade_history_item" -> {
                    // Fetch valid history IDs
                    val historyIds = db.tradeHistoryDao()
                        .getAll()
                        .map { it.tradeHistoryId }
                        .joinToString(", ")
                    // Short→full type map
                    val typeMap = mapOf(
                        "seed" to "seed",
                        "prod" to "product",
                        "misc" to "miscellaneous_item",
                        "bio"  to "biochemical_item"
                    )
                    // Provide concise hints for all fields
                    columnsAdapter.setHints(mapOf(
                        "trade_history_id" to if (historyIds.isEmpty())
                            "No history (create one first)"
                        else
                            "Hist#: $historyIds",
                        // only the short keys shown here
                        "item_type"        to "Type: ${typeMap.keys.joinToString("/")}",
                        "item_id"          to "Enter ID for chosen type"
                    ))
                    view.findViewById<Button>(R.id.btn_editdata_submit).isEnabled =
                        historyIds.isNotEmpty()
                }

                else -> {
                    columnsAdapter.setHints(emptyMap())
                }
            } // hint for edit

            columnsAdapter.setItems(getFieldsForTable(table))

            // load existing values
            when(table) {
                "farm" -> db.farmDao().getFarmById(itemId)?.let {
                    columnsAdapter.setItemsFromMap(mapOf(
                        "farm_id" to it.farmId.toString(),
                        "user_id" to it.userId.toString(),
                        "farm_name" to it.farmName,
                        "farm_info" to it.farmInfo
                    ))
                }
                "warehouse" -> db.warehouseDao().getWarehouseById(itemId)?.let {
                    columnsAdapter.setItemsFromMap(mapOf(
                        "warehouse_id" to it.warehouseId.toString(),
                        "warehouse_name" to it.warehouseName,
                        "warehouse_capacity" to it.warehouseCapacity.toString(),
                        "farm_id" to it.farmId.toString()
                    ))
                }
                "farming_field" -> db.farmingFieldDao().getFieldById(itemId)?.let {
                    columnsAdapter.setItemsFromMap(mapOf(
                        "field_id"   to it.fieldId.toString(),
                        "farm_id"    to it.farmId.toString(),
                        "field_name" to it.fieldName,
                        "field_type" to it.fieldType
                    ))
                }
                "trader" -> db.traderDao().getById(itemId)?.let {
                    columnsAdapter.setItemsFromMap(mapOf(
                        "trader_id"          to it.traderId.toString(),
                        "trader_name"        to it.traderName,
                        "trader_type"        to it.traderType,
                        "trader_email"       to it.traderEmail,
                        "trader_contact"     to it.traderContact,
                        "trader_description" to it.traderDescription
                    ))
                }
                "trade_history" -> db.tradeHistoryDao().getById(itemId)?.let {
                    columnsAdapter.setItemsFromMap(mapOf(
                        "trader_id"    to it.traderId.toString(),
                        "farm_id"      to it.farmId.toString(),
                        "warehouse_id" to it.warehouseId.toString(),
                        "trade_date"   to it.tradeDate,
                        "trade_type"   to it.tradeType
                    ))
                }
                "seed" -> db.seedDao().getById(itemId)?.let {
                    columnsAdapter.setItemsFromMap(mapOf(
                        "seed_id"       to it.seedId.toString(),
                        "warehouse_id"  to it.warehouseId.toString(),
                        "seed_name"     to it.seedName,
                        "seed_unit"     to it.seedUnit,
                        "seed_quantity" to it.seedQuantity.toString()
                    ))
                }
                "product" -> db.productDao().getById(itemId)?.let {
                    columnsAdapter.setItemsFromMap(mapOf(
                        "product_id"       to it.productId.toString(),
                        "warehouse_id"     to it.warehouseId.toString(),
                        "product_name"     to it.productName,
                        "product_unit"     to it.productUnit,
                        "product_quantity" to it.productQuantity.toString()
                    ))
                }
                "miscellaneous_item" -> db.miscellaneousItemDao().getById(itemId)?.let {
                    columnsAdapter.setItemsFromMap(mapOf(
                        "miscellaneous_item_id"          to it.miscellaneousItemId.toString(),
                        "warehouse_id"                   to it.warehouseId.toString(),
                        "miscellaneous_item_name"        to it.itemName,
                        "miscellaneous_item_description" to it.itemDescription,
                        "miscellaneous_item_unit"        to it.itemUnit,
                        "miscellaneous_item_quantity"    to it.itemQuantity.toString()
                    ))
                }
                "biochemical_item" -> db.biochemicalItemDao().getById(itemId)?.let {
                    columnsAdapter.setItemsFromMap(mapOf(
                        "biochemical_item_id"          to it.biochemicalItemId.toString(),
                        "warehouse_id"                 to it.warehouseId.toString(),
                        "biochemical_item_name"        to it.itemName,
                        "biochemical_item_description" to it.itemDescription,
                        "biochemical_item_unit"        to it.itemUnit,
                        "biochemical_item_quantity"    to it.itemQuantity.toString()
                    ))
                }
                "trade_history_item" -> db.tradeHistoryItemDao().getById(itemId)?.let {
                    columnsAdapter.setItemsFromMap(mapOf(
                        "trade_history_item_id" to it.tradeHistoryItemId.toString(),
                        "trade_history_id"      to it.tradeHistoryId.toString(),
                        "item_type"             to it.itemType,
                        "item_id"               to it.itemId.toString(),
                        "quantity"              to it.quantity.toString(),
                        "price"                 to it.price.toString()
                    ))
                }

            }
        }

        view.findViewById<Button>(R.id.btn_editdata_submit).setOnClickListener {
            val edited = columnsAdapter.getEditedItems().associate { it.key to it.value }
            lifecycleScope.launch {
                when (table) {
                    "farm" -> {
                        val fid   = edited["farm_id"]?.toIntOrNull()
                        val uid   = edited["user_id"]?.toIntOrNull()
                        val nm    = edited["farm_name"].orEmpty()
                        val info  = edited["farm_info"].orEmpty()

                        // verify user exists
                        val user = db.userDao().getUserById(uid ?: -1)
                        if (user == null) {
                            Toast.makeText(requireContext(),
                                "User ID not found; please choose a valid User",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        if (fid == null || nm.isBlank()) {
                            Toast.makeText(requireContext(),
                                "Please enter a farm name",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        db.farmDao().updateFarm(
                            FarmEntity(
                                farmId   = fid,
                                userId   = uid!!,
                                farmName = nm,
                                farmInfo = info
                            )
                        )
                        navigateToDatabaseBrowsing(requireContext())
                    }

                    "warehouse" -> {
                        val id     = itemId
                        val edited = columnsAdapter.getEditedItems().associate { it.key to it.value }
                        val farmId = edited["farm_id"]?.toIntOrNull() ?: 0
                        val name   = edited["warehouse_name"].orEmpty()
                        val cap    = edited["warehouse_capacity"]?.toIntOrNull() ?: 0

                        // verify farm exists
                        val farm = db.farmDao().getFarmById(farmId)
                        if (farm == null) {
                            Toast.makeText(requireContext(),
                                "Farm ID not found; please choose a valid Farm",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        if (name.isBlank() || cap <= 0) {
                            Toast.makeText(requireContext(),
                                "Please enter a name and positive capacity",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        db.warehouseDao().updateWarehouse(
                            WarehouseEntity(
                                warehouseId       = id,
                                warehouseName     = name,
                                warehouseCapacity = cap,
                                farmId            = farmId
                            )
                        )
                        navigateToDatabaseBrowsing(requireContext())
                    }

                    "farming_field" -> {
                        val fid   = edited["field_id"]?.toIntOrNull()
                        val farm  = edited["farm_id"]?.toIntOrNull()
                        val nm    = edited["field_name"].orEmpty()
                        val tp    = edited["field_type"].orEmpty()

                        // verify farm exists
                        val parentFarm = db.farmDao().getFarmById(farm ?: -1)
                        if (parentFarm == null) {
                            Toast.makeText(requireContext(),
                                "Farm ID not found; please choose a valid Farm",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        if (fid == null || nm.isBlank() || tp.isBlank()) {
                            Toast.makeText(requireContext(),
                                "Please enter field name and type",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        db.farmingFieldDao().updateField(
                            FarmingFieldEntity(
                                fieldId   = fid,
                                fieldName = nm,
                                fieldType = tp,
                                farmId    = farm!!
                            )
                        )
                        navigateToDatabaseBrowsing(requireContext())
                    }

                    "trader" -> {
                        val id          = itemId
                        val name        = edited["trader_name"].orEmpty()
                        val type        = edited["trader_type"].orEmpty()
                        val email       = edited["trader_email"].orEmpty()
                        val contact     = edited["trader_contact"].orEmpty()
                        val description = edited["trader_description"].orEmpty()

                        if (name.isBlank() || type.isBlank() || email.isBlank()) {
                            Toast.makeText(requireContext(),
                                "Please enter at least name, type, and email",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        db.traderDao().update(
                            TraderEntity(
                                traderId          = id,
                                traderName        = name,
                                traderType        = type,
                                traderEmail       = email,
                                traderContact     = contact,
                                traderDescription = description
                            )
                        )
                        navigateToDatabaseBrowsing(requireContext())
                    }

                    "trade_history" -> {
                        val id           = itemId
                        val traderId     = edited["trader_id"]?.toIntOrNull() ?: 0
                        val warehouseId  = edited["warehouse_id"]?.toIntOrNull() ?: 0
                        val date         = edited["trade_date"].orEmpty()
                        val type         = edited["trade_type"].orEmpty()

                        val warehouse = db.warehouseDao().getWarehouseById(warehouseId)
                        if (traderId <= 0 || warehouse == null || date.isBlank() || type.isBlank()) {
                            Toast.makeText(requireContext(),
                                "Please fill in all Trade History fields with valid values",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        val farmId = warehouse.farmId
                        db.tradeHistoryDao().update(
                            TradeHistoryEntity(
                                tradeHistoryId = id,
                                traderId       = traderId,
                                farmId         = farmId,
                                warehouseId    = warehouseId,
                                tradeDate      = date,
                                tradeType      = type
                            )
                        )
                        navigateToDatabaseBrowsing(requireContext())
                    }

                    "seed" -> {
                        val id       = itemId
                        val wid      = edited["warehouse_id"]?.toIntOrNull() ?: 0
                        val name     = edited["seed_name"].orEmpty()
                        val unit     = edited["seed_unit"].orEmpty()
                        val quantity = edited["seed_quantity"]?.toIntOrNull() ?: 0

                        val warehouse = db.warehouseDao().getWarehouseById(wid)
                        if (warehouse == null) {
                            Toast.makeText(requireContext(),
                                "Warehouse ID not found; please choose a valid Warehouse",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        if (name.isBlank() || unit.isBlank() || quantity <= 0) {
                            Toast.makeText(requireContext(),
                                "Please fill in name, unit, and a positive quantity",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        db.seedDao().update(
                            SeedEntity(
                                seedId       = id,
                                warehouseId  = wid,
                                seedName     = name,
                                seedUnit     = unit,
                                seedQuantity = quantity
                            )
                        )
                        navigateToDatabaseBrowsing(requireContext())
                    }

                    "product" -> {
                        val id       = itemId
                        val wid      = edited["warehouse_id"]?.toIntOrNull() ?: 0
                        val name     = edited["product_name"].orEmpty()
                        val unit     = edited["product_unit"].orEmpty()
                        val quantity = edited["product_quantity"]?.toIntOrNull() ?: 0

                        val warehouse = db.warehouseDao().getWarehouseById(wid)
                        if (warehouse == null) {
                            Toast.makeText(requireContext(),
                                "Warehouse ID not found; please choose a valid Warehouse",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        if (name.isBlank() || unit.isBlank() || quantity <= 0) {
                            Toast.makeText(requireContext(),
                                "Please fill in name, unit, and a positive quantity",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        db.productDao().update(
                            ProductEntity(
                                productId       = id,
                                warehouseId     = wid,
                                productName     = name,
                                productUnit     = unit,
                                productQuantity = quantity
                            )
                        )
                        navigateToDatabaseBrowsing(requireContext())
                    }

                    "miscellaneous_item" -> {
                        val id       = itemId
                        val wid      = edited["warehouse_id"]?.toIntOrNull() ?: 0
                        val name     = edited["miscellaneous_item_name"].orEmpty()
                        val desc     = edited["miscellaneous_item_description"].orEmpty()
                        val unit     = edited["miscellaneous_item_unit"].orEmpty()
                        val quantity = edited["miscellaneous_item_quantity"]?.toIntOrNull() ?: 0

                        val warehouse = db.warehouseDao().getWarehouseById(wid)
                        if (warehouse == null) {
                            Toast.makeText(requireContext(),
                                "Warehouse ID not found; please choose a valid Warehouse",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        if (name.isBlank() || desc.isBlank() || unit.isBlank() || quantity <= 0) {
                            Toast.makeText(requireContext(),
                                "Fill all fields with valid values",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        db.miscellaneousItemDao().update(
                            MiscellaneousItemEntity(
                                miscellaneousItemId = id,
                                warehouseId         = wid,
                                itemName            = name,
                                itemDescription     = desc,
                                itemUnit            = unit,
                                itemQuantity        = quantity
                            )
                        )
                        navigateToDatabaseBrowsing(requireContext())
                    }

                    "biochemical_item" -> {
                        val id       = itemId
                        val wid      = edited["warehouse_id"]?.toIntOrNull() ?: 0
                        val name     = edited["biochemical_item_name"].orEmpty()
                        val desc     = edited["biochemical_item_description"].orEmpty()
                        val unit     = edited["biochemical_item_unit"].orEmpty()
                        val quantity = edited["biochemical_item_quantity"]?.toIntOrNull() ?: 0

                        val warehouse = db.warehouseDao().getWarehouseById(wid)
                        if (warehouse == null) {
                            Toast.makeText(requireContext(),
                                "Warehouse ID not found; please choose a valid Warehouse",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        if (name.isBlank() || desc.isBlank() || unit.isBlank() || quantity <= 0) {
                            Toast.makeText(requireContext(),
                                "Fill all fields with valid values",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        db.biochemicalItemDao().update(
                            BiochemicalItemEntity(
                                biochemicalItemId = id,
                                warehouseId       = wid,
                                itemName          = name,
                                itemDescription   = desc,
                                itemUnit          = unit,
                                itemQuantity      = quantity
                            )
                        )
                        navigateToDatabaseBrowsing(requireContext())
                    }
                    "trade_history_item" -> {
                        val e          = columnsAdapter.getEditedItems().associate { it.key to it.value }
                        val histId     = e["trade_history_id"]?.toIntOrNull() ?: 0
                        // Map short input to full type
                        val shortType  = e["item_type"]?.trim()?.lowercase().orEmpty()
                        val typeMap    = mapOf(
                            "seed" to "seed",
                            "prod" to "product",
                            "misc" to "miscellaneous_item",
                            "bio"  to "biochemical_item"
                        )
                        val fullType   = typeMap[shortType]
                        if (fullType == null) {
                            Toast.makeText(
                                requireContext(),
                                "Type must be one of: ${typeMap.keys.joinToString(", ")}",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        val itemId     = e["item_id"]?.toIntOrNull() ?: 0
                        val qty        = e["quantity"]?.toIntOrNull() ?: 0
                        val price      = e["price"]?.toDoubleOrNull() ?: -1.0
                        // Validate FKs and inputs
                        if (db.tradeHistoryDao().getById(histId) == null) {
                            Toast.makeText(requireContext(), "Trade History ID not found", Toast.LENGTH_SHORT).show()
                            return@launch
                        }
                        val exists = when (fullType) {
                            "seed"               -> db.seedDao().getById(itemId) != null
                            "product"            -> db.productDao().getById(itemId) != null
                            "miscellaneous_item" -> db.miscellaneousItemDao().getById(itemId) != null
                            "biochemical_item"   -> db.biochemicalItemDao().getById(itemId) != null
                            else                 -> false
                        }
                        if (!exists) {
                            Toast.makeText(
                                requireContext(),
                                "No $fullType found with ID $itemId",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        if (qty <= 0 || price < 0.0) {
                            Toast.makeText(
                                requireContext(),
                                "Enter a positive quantity and non-negative price",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@launch
                        }
                        //Insert with the full type
                        db.tradeHistoryItemDao().insert(
                            TradeHistoryItemEntity(
                                tradeHistoryId = histId,
                                itemType       = fullType,
                                itemId         = itemId,
                                quantity       = qty,
                                price          = price
                            )
                        )
                        navigateToDatabaseBrowsing(requireContext())
                    }

                }// when()
            }

        }
        view.findViewById<Button>(R.id.btn_editdata_cancel).setOnClickListener {
            navigateToDatabaseBrowsing(requireContext())
        }
    }
}
