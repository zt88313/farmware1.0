package com.example.farmware.offlinebase.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.farmware.offlinebase.entities.ProductEntity

@Dao
interface ProductDao {

    @Insert
    suspend fun insert(product: ProductEntity): Long

    @Query("SELECT * FROM product")
    suspend fun getAll(): List<ProductEntity>

    @Query("SELECT * FROM product WHERE product_id = :id")
    suspend fun getById(id: Int): ProductEntity?

    @Query("SELECT * FROM product WHERE warehouse_id = :warehouseId")
    suspend fun getByWarehouse(warehouseId: Int): List<ProductEntity>

    @Update
    suspend fun update(product: ProductEntity)

    @Query("DELETE FROM product WHERE product_id = :id")
    suspend fun deleteById(id: Int)
}
