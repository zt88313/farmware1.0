package com.example.farmware.offlinebase.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "miscellaneous_item")
data class MiscellaneousItemEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "miscellaneous_item_id")
    val miscellaneousItemId: Int = 0,

    @ColumnInfo(name = "warehouse_id")
    val warehouseId: Int,

    @ColumnInfo(name = "miscellaneous_item_name")
    val itemName: String,

    @ColumnInfo(name = "miscellaneous_item_description")
    val itemDescription: String,

    @ColumnInfo(name = "miscellaneous_item_unit")
    val itemUnit: String,

    @ColumnInfo(name = "miscellaneous_item_quantity")
    val itemQuantity: Int
)
