package com.example.farmware

import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ReportChoosingActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_report_choosing)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Find views
        val btnReport1 = findViewById<Button>(R.id.btn_repo_1)
        val btnReport2 = findViewById<Button>(R.id.btn_repo_2)
        val btnReport3 = findViewById<Button>(R.id.btn_repo_3)
        val btnBack    = findViewById<ImageButton>(R.id.ibtn_back_report_choose)

        // Click listeners
        btnReport1.setOnClickListener {
            Toast.makeText(this, "Report 1 selected", Toast.LENGTH_SHORT).show()

        }

        btnReport2.setOnClickListener {
            Toast.makeText(this, "Report 2 selected", Toast.LENGTH_SHORT).show()

        }

        btnReport3.setOnClickListener {
            Toast.makeText(this, "Report 3 selected", Toast.LENGTH_SHORT).show()

        }

        btnBack.setOnClickListener {
            jumpToHomePage(this)
        }
    }



}