package com.example.farmware.fragments

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.example.farmware.FeedbackMessage
import com.example.farmware.R
import com.example.farmware.jumpToHomePage

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FeedbackFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class FeedbackFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_feedback, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val layoutMessages = view.findViewById<LinearLayout>(R.id.layout_feedback_messages)
        val tvContact = view.findViewById<TextView>(R.id.tv_contact_message)
        val btnCopyContact = view.findViewById<Button>(R.id.btn_copy_contact)
        val btnBack = view.findViewById<ImageButton>(R.id.ibtn_back_feedback)


        //Only show feedback messages, exclude the contact/email ones
        FeedbackMessage.values()
            .filter { it != FeedbackMessage.CONTACT_US && it != FeedbackMessage.CONTACT_EMAIL }
            .forEach { message ->
                val tv = TextView(requireContext()).apply {
                    text = message.text
                    textSize = 16f
                    setPadding(0, 0, 0, 8)
                    setTextIsSelectable(true)  // allow text selection
                }

                val divider = View(requireContext()).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 1
                    )
                    setBackgroundColor(resources.getColor(android.R.color.darker_gray, null))
                }

                layoutMessages.addView(tv)
                layoutMessages.addView(divider)
            }

        // Set special CONTACT_US section without repeating above
        val contactText = FeedbackMessage.CONTACT_US.text + " " + FeedbackMessage.CONTACT_EMAIL.text
        tvContact.text = contactText
        tvContact.setTextIsSelectable(true)  // allow long-press copy


        btnCopyContact.setOnClickListener {
            val emailOnly = FeedbackMessage.CONTACT_EMAIL.text

            val clipboard = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("contact_email", emailOnly)
            clipboard.setPrimaryClip(clip)

            Toast.makeText(requireContext(), "Email copied: $emailOnly", Toast.LENGTH_SHORT).show()
        }

        btnBack.setOnClickListener {
            jumpToHomePage(requireContext())
        }
    }



    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FeedbackFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FeedbackFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}