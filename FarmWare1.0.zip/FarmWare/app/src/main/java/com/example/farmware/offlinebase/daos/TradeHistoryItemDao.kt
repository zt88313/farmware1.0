package com.example.farmware.offlinebase.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.farmware.offlinebase.entities.TradeHistoryItemEntity

@Dao
interface TradeHistoryItemDao {

    @Insert
    suspend fun insert(item: TradeHistoryItemEntity): Long

    @Query("SELECT * FROM trade_history_item")
    suspend fun getAll(): List<TradeHistoryItemEntity>

    @Query("SELECT * FROM trade_history_item WHERE trade_history_item_id = :id")
    suspend fun getById(id: Int): TradeHistoryItemEntity?

    @Query("SELECT * FROM trade_history_item WHERE trade_history_id = :historyId")
    suspend fun getByHistoryId(historyId: Int): List<TradeHistoryItemEntity>

    @Update
    suspend fun update(item: TradeHistoryItemEntity)

    @Query("DELETE FROM trade_history_item WHERE trade_history_item_id = :id")
    suspend fun deleteById(id: Int)
}
