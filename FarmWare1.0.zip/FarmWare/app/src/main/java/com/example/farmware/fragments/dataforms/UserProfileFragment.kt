package com.example.farmware.fragments.dataforms

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.farmware.LocalDatabase
import com.example.farmware.PrefsManager
import com.example.farmware.R
import com.example.farmware.jumpToHomePage
import com.example.farmware.offlinebase.entities.UserEntity
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class UserProfileFragment : Fragment(R.layout.fragment_user_profile) {
    private lateinit var ivProfile: ImageView
    private lateinit var etName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnSave: Button
    private lateinit var btnCancel: Button

    private var tempBitmap: Bitmap? = null               // buffer for camera thumbnail
    private var originalUriString: String? = null        // remember original on entry
    private var selectedImageUri: Uri? = null
    private var userId: Int = -1

    private var pictureChanged = false

    companion object {
        private const val REQ_CAMERA  = 1001
        private const val REQ_GALLERY = 1002
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        ivProfile  = view.findViewById(R.id.iv_profile_picture)
        etName     = view.findViewById(R.id.et_profile_username)
        etEmail    = view.findViewById(R.id.et_profile_email)
        etPassword = view.findViewById(R.id.et_profile_password)
        btnSave    = view.findViewById(R.id.btn_profile_save)
        btnCancel  = view.findViewById(R.id.btn_profile_cancel)

        ivProfile.setImageResource(R.drawable.nophoto)

        // Retrieve current user ID
        userId = PrefsManager.getLoggedInUserId(requireContext())
        if (userId <= 0) return

        // Ensure profile_pics dir exists
        getProfilePicDir().apply { if (!exists()) mkdirs() }

        // Load existing user & picture (no password)
        lifecycleScope.launch {
            LocalDatabase.getDatabase(requireContext())
                .userDao().getUserById(userId)
                ?.let { user ->
                    etName.setText(user.userName)
                    etEmail.setText(user.userEmail)
                    originalUriString = user.profilePicUri

                    // if have a saved URI, load it; otherwise show placeholder
                    user.profilePicUri?.let { uriStr ->
                        val uri = Uri.parse(uriStr)
                        selectedImageUri = uri
                        ivProfile.setImageURI(uri)
                    } ?: run {
                        // No URI stored , show nophoto.png
                        ivProfile.setImageResource(R.drawable.nophoto)
                    }
                }
        }

        // Tap image to choose source
        ivProfile.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Select Picture")
                .setItems(arrayOf("Take Photo", "Choose from Gallery", "Cancel")) { dlg, which ->
                    when (which) {
                        0 -> openCamera()
                        1 -> openGallery()
                        else -> dlg.dismiss()
                    }
                }
                .show()
        }

        // Save commits the preview to disk & DB
        btnSave.setOnClickListener {

            lifecycleScope.launch {
                val dao     = LocalDatabase.getDatabase(requireContext()).userDao()
                val current = dao.getUserById(userId) ?: return@launch

                val file = getProfilePicFile()
                var finalUriString = originalUriString

                if (pictureChanged) {
                    // user picked/snapped a new picture → overwrite file
                    tempBitmap?.let { bmp ->
                        FileOutputStream(file).use { out ->
                            bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
                        }
                    }
                    selectedImageUri?.let { uri ->
                        requireContext().contentResolver.openInputStream(uri).use { inp ->
                            FileOutputStream(file).use { out -> inp?.copyTo(out) }
                        }
                    }
                    // update our in‐app Uri
                    finalUriString = FileProvider.getUriForFile(
                        requireContext(),
                        "${requireContext().packageName}.provider",
                        file
                    ).toString()
                }

                // choose new password if entered, else keep existing
                val passInput = etPassword.text.toString()

                val finalPassword = if (passInput.isBlank()) current.userPassword
                else passInput.reversed()

                // update record with finalUriString (original or new)
                val updated = UserEntity(
                    userId        = userId,
                    userName      = etName.text.toString().trim(),
                    userEmail     = etEmail.text.toString().trim(),
                    userPassword  = finalPassword,
                    profilePicUri = finalUriString
                )
                dao.updateUser(updated)

                Toast.makeText(requireContext(),
                    "Profile updated", Toast.LENGTH_SHORT).show()
                jumpToHomePage(requireContext())
            }
        }

        // Cancel discards preview, restores original
        btnCancel.setOnClickListener {
            tempBitmap = null
            selectedImageUri = originalUriString?.let { Uri.parse(it) }
            selectedImageUri?.let { ivProfile.setImageURI(it) }
            jumpToHomePage(requireContext())
        }
    }

    // capture thumbnail
    private fun openCamera() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also {
            startActivityForResult(it, REQ_CAMERA)
        }
    }

    // pick from gallery
    private fun openGallery() {
        Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).also {
            startActivityForResult(it, REQ_GALLERY)
        }
    }

    // preview in-memory only
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        when (requestCode) {
            REQ_CAMERA -> {
                tempBitmap = data?.extras?.get("data") as? Bitmap
                selectedImageUri = null
                tempBitmap?.let { ivProfile.setImageBitmap(it) }
                pictureChanged = true
            }
            REQ_GALLERY -> {
                data?.data?.let { uri ->
                    tempBitmap = null
                    selectedImageUri = uri
                    ivProfile.setImageURI(uri)
                    pictureChanged = true
                }
            }
        }
    }

    private fun getProfilePicDir(): File =
        File(requireContext().filesDir, "profile_pics")

    private fun getProfilePicFile(): File =
        File(getProfilePicDir(), "profile_${userId}.jpg")
}
