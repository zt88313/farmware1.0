package com.example.farmware.apptools

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.farmware.R

data class EditableItem(val key: String, var value: String)

class SelectedItemDataAdapter(
    private val context: Context
) : RecyclerView.Adapter<SelectedItemDataAdapter.DataViewHolder>() {

    private val dataSet = mutableListOf<EditableItem>()
    private val hintsMap = mutableMapOf<String, String>()

    /**
     * Provide form fields in order. Keys should match entity columns.
     */
    fun setItems(fields: List<String>) {
        dataSet.clear()
        dataSet.addAll(fields.map { EditableItem(it, "") })
        notifyDataSetChanged()
    }

    /**
     * Provide hint messages per field key (e.g. "farm_id" -> "Available: 1, 2, 3").
     */
    fun setHints(hints: Map<String, String>) {
        hintsMap.clear()
        hintsMap.putAll(hints)
    }

    fun getEditedItems(): List<EditableItem> = dataSet

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.selected_item_data, parent, false)
        return DataViewHolder(view)
    }

    override fun onBindViewHolder(holder: DataViewHolder, position: Int) {
        val item = dataSet[position]
        val displayKey = item.key.replace('_', ' ')
        holder.keyView.text = displayKey

        // Configure marquee for key
        holder.keyView.isSingleLine = true
        holder.keyView.ellipsize = android.text.TextUtils.TruncateAt.MARQUEE
        holder.keyView.marqueeRepeatLimit = -1
        holder.keyView.isFocusable = true
        holder.keyView.isFocusableInTouchMode = true
        holder.keyView.isSelected = true

        // Set value and hint
        holder.valueEdit.setText(item.value)
        holder.valueEdit.hint = hintsMap[item.key] ?: displayKey
        holder.valueEdit.isSingleLine = true
        holder.valueEdit.isHorizontalScrollBarEnabled = true
        holder.valueEdit.isSelected = true

        // Disable editing only for primary keys (no hint) but allow foreign keys if hint provided
        val isIdField = item.key.lowercase().endsWith("_id")
        val hasHint = hintsMap.containsKey(item.key)
        holder.valueEdit.isEnabled = !(isIdField && !hasHint)

        if (item.key == "trade_date") {
            holder.valueEdit.isEnabled = false
        }

        if (holder.valueEdit.isEnabled) {
            holder.valueEdit.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    dataSet[holder.adapterPosition].value = s.toString()
                }
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            })
        }
    }

    override fun getItemCount(): Int = dataSet.size

    fun setItemsFromMap(dataMap: Map<String, String>) {
        dataSet.clear()
        dataSet.addAll(dataMap.map { EditableItem(it.key, it.value) })
        notifyDataSetChanged()
    }

    class DataViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val keyView: TextView = itemView.findViewById(R.id.keyText)
        val valueEdit: EditText = itemView.findViewById(R.id.valueEdit)
    }
}
