package com.example.farmware

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.farmware.fragments.auth.ForgotPasswordFragment
import com.example.farmware.fragments.auth.LoginFragment
import com.example.farmware.fragments.auth.SignupFragment

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Make status bar transparent
        window.apply {
            clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            statusBarColor = Color.TRANSPARENT
            // Only set LIGHT_STATUS_BAR so icons are dark, but DO NOT use LAYOUT_FULLSCREEN
            decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }

        // Load LoginFragment on first launch
        if (savedInstanceState == null) {
            showLoginFragment()
        }
    }

    /** Replace container with LoginFragment, clearing back-stack */
    fun showLoginFragment() {
        supportFragmentManager.popBackStack()   // ensure no leftover
        supportFragmentManager.beginTransaction()
            .replace(R.id.fl_holder, LoginFragment())
            .commit()
    }

    /** Push SignupFragment on top of LoginFragment */
    fun showSignupFragment() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fl_holder, SignupFragment())
            .addToBackStack(null)
            .commit()
    }

    fun showForgotPasswordFragment() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fl_holder, ForgotPasswordFragment())
            .addToBackStack(null)
            .commit()
    }
}
