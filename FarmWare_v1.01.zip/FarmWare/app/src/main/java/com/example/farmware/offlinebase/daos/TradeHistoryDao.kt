package com.example.farmware.offlinebase.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.farmware.offlinebase.entities.TradeHistoryEntity

@Dao
interface TradeHistoryDao {

    @Insert
    suspend fun insert(tradeHistory: TradeHistoryEntity): Long

    @Query("SELECT * FROM trade_history")
    suspend fun getAll(): List<TradeHistoryEntity>

    @Query("SELECT * FROM trade_history WHERE trade_history_id = :id")
    suspend fun getById(id: Int): TradeHistoryEntity?

    @Update
    suspend fun update(tradeHistory: TradeHistoryEntity)

    @Query("DELETE FROM trade_history WHERE trade_history_id = :id")
    suspend fun deleteById(id: Int)
}
