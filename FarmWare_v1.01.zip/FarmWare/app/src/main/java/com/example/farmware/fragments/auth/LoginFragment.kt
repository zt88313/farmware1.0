package com.example.farmware.fragments.auth

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.example.farmware.LocalDatabase
import com.example.farmware.LoginActivity
import com.example.farmware.PrefsManager
import com.example.farmware.R
import com.example.farmware.databinding.FragmentLoginBinding
import com.example.farmware.goChooseMode
import com.example.farmware.jumpToHomePage
import com.example.farmware.offlinebase.entities.UserEntity
import kotlinx.coroutines.launch
class LoginFragment : Fragment() {
    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = FragmentLoginBinding.inflate(inflater, container, false).also {
        _binding = it
    }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val checkBox = view.findViewById<CheckBox>(R.id.cbx_remember)
        checkBox.isChecked = PrefsManager.isRememberMeChecked(requireContext())
        if (checkBox.isChecked) {
            PrefsManager.getRememberedUser(requireContext()).let { (user, pass) ->
                user?.let { binding.editTextTextEmailAddress.setText(it) }
                pass?.let { binding.editTextTextPassword.setText(it) }
            }
        }

        // Insert a test user if none exists
        lifecycleScope.launch {
            val dao = LocalDatabase.getDatabase(requireContext()).userDao()
            val testUsername = "admin"
            val testPassword = "123456"
            val testHash = hashPassword(testPassword)

            if (dao.getUserByUsername(testUsername) == null) {
                val fakeUser = UserEntity(
                    userName     = testUsername,
                    userEmail    = "$testUsername@example.com",
                    userPassword = testHash
                )
                dao.insert(fakeUser)
            }
        }

        binding.btnLogin.setOnClickListener {
            val username = binding.editTextTextEmailAddress.text.toString()
            val password = binding.editTextTextPassword.text.toString()
            val hashed   = hashPassword(password)

            lifecycleScope.launch {
                val dao = LocalDatabase.getDatabase(requireContext()).userDao()
                val user = dao.getUserByUsername(username)

                if (user != null && user.userPassword == hashed) {
                    PrefsManager.setLoggedInUserId(requireContext(), user.userId)
                    PrefsManager.setRememberMeChecked(requireContext(), checkBox.isChecked)
                    if (checkBox.isChecked) {
                        PrefsManager.updateRememberedUserIfChanged(
                            requireContext(), username, password
                        )
                    } else {
                        PrefsManager.clearRememberedUser(requireContext())
                    }
                    jumpToHomePage(requireContext())
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Invalid username or password",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        binding.tvSignup.setOnClickListener {
            // swap in the signup screen
            (activity as? LoginActivity)?.showSignupFragment()
        }

        binding.tvForgotPassword.setOnClickListener {
            // swap in the ForgotPasswordFragment
            (activity as? LoginActivity)?.showForgotPasswordFragment()
        }
        binding.ibtnBackLogin.setOnClickListener {
            // back
            goChooseMode(requireContext())
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }



    private fun hashPassword(password: String): String =
        password.reversed()  // temporary
}
