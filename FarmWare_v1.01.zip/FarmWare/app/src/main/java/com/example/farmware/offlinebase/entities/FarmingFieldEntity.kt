package com.example.farmware.offlinebase.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    foreignKeys = [
        ForeignKey(
            entity        = FarmEntity::class,
            parentColumns = ["farm_id"],
            childColumns  = ["farm_id"],
            onDelete      = ForeignKey.CASCADE
        )
    ]
)
data class FarmingFieldEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "field_id")
    val fieldId: Int = 0,

    @ColumnInfo(name = "field_name")
    val fieldName: String,

    @ColumnInfo(name = "field_type")
    val fieldType: String,

    @ColumnInfo(name = "farm_id")
    val farmId: Int   // ← now matches the FK column name
)
