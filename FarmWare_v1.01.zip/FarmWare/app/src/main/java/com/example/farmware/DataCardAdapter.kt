package com.example.farmware

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DataCardAdapter(private val items: MutableList<DataItem>) :
    RecyclerView.Adapter<DataCardAdapter.DatacardViewHolder>() {

    fun updateData(newItems: List<DataItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    var onDeleteClicked: ((Int) -> Unit)? = null

    class DatacardViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val itemName: TextView = view.findViewById(R.id.tv_itemname)
        val itemInfo: TextView = view.findViewById(R.id.tv_iteminfo)
        val btnEdit: Button = view.findViewById(R.id.btn_edit)
        val btnDelete: Button = view.findViewById(R.id.btn_delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DatacardViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.datacard, parent, false)
        return DatacardViewHolder(view)
    }



    override fun onBindViewHolder(holder: DatacardViewHolder, position: Int) {
        holder.itemName.text = items[position].name
        holder.itemInfo.text = items[position].info

        holder.btnEdit.setOnClickListener {
            val itemId = items[position].id
            jumpToDataform(holder.itemView.context, itemId, "editData")
        }
        holder.btnDelete.setOnClickListener {
            onDeleteClicked?.invoke(holder.adapterPosition)
        }

    }

    override fun getItemCount(): Int = items.size


}
