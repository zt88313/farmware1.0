package com.example.farmware.offlinebase.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "farm",
    foreignKeys = [
        ForeignKey(
            entity = UserEntity::class,
            parentColumns = ["user_id"],
            childColumns = ["user_id"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class FarmEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "farm_id")
    val farmId: Int = 0,

    @ColumnInfo(name = "user_id")
    val userId: Int,

    @ColumnInfo(name = "farm_name")
    val farmName: String,

    @ColumnInfo(name = "farm_info")
    val farmInfo: String
)
