package com.example.farmware.offlinebase.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "biochemical_item")
data class BiochemicalItemEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "biochemical_item_id")
    val biochemicalItemId: Int = 0,

    @ColumnInfo(name = "warehouse_id")
    val warehouseId: Int,

    @ColumnInfo(name = "biochemical_item_name")
    val itemName: String,

    @ColumnInfo(name = "biochemical_item_description")
    val itemDescription: String,

    @ColumnInfo(name = "biochemical_item_unit")
    val itemUnit: String,

    @ColumnInfo(name = "biochemical_item_quantity")
    val itemQuantity: Int
)
