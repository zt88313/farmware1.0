package com.example.farmware.offlinebase.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.farmware.offlinebase.entities.BiochemicalItemEntity

@Dao
interface BiochemicalItemDao {

    @Insert
    suspend fun insert(item: BiochemicalItemEntity): Long

    @Query("SELECT * FROM biochemical_item")
    suspend fun getAll(): List<BiochemicalItemEntity>

    @Query("SELECT * FROM biochemical_item WHERE biochemical_item_id = :id")
    suspend fun getById(id: Int): BiochemicalItemEntity?

    @Query("SELECT * FROM biochemical_item WHERE warehouse_id = :warehouseId")
    suspend fun getByWarehouse(warehouseId: Int): List<BiochemicalItemEntity>

    @Update
    suspend fun update(item: BiochemicalItemEntity)

    @Query("DELETE FROM biochemical_item WHERE biochemical_item_id = :id")
    suspend fun deleteById(id: Int)
}
