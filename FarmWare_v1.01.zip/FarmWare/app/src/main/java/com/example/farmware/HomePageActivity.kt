package com.example.farmware

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.farmware.PrefsManager.getNetworkState
import kotlinx.coroutines.launch


class HomePageActivity : AppCompatActivity() {

    private lateinit var intent: Intent

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home_page)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //link items
        val ibtnProfile = findViewById<ImageButton>(R.id.ibtn_profile)
        val btnFarmdata = findViewById<Button>(R.id.btn_farmdata)
        val btnReport = findViewById<Button>(R.id.btn_report)
        val btnFeedback = findViewById<Button>(R.id.btn_feedback)
        val tvNetstate: TextView = findViewById(R.id.tv_netstate)
        val btnOut = findViewById<ImageButton>(R.id.ibtn_back_home)
        val ivNews = findViewById<ImageView>(R.id.gif_news)
        val tvNews = findViewById<TextView>(R.id.tv_news)

        ibtnProfile.setOnClickListener {
            jumpToProfileEditingForm(this)
        }
        btnFarmdata.setOnClickListener {
            jumpToDatabaseBrowsing(this)
        }
        btnReport.setOnClickListener {
            goReportChoosing(this)
        }
        btnFeedback.setOnClickListener {
            navigateToFeedbackForm(this)
        }
        btnOut.setOnClickListener {
            showLogoutConfirmation()
        }

        tvNetstate.text = getNetworkState(this)

        Glide.with(this)
            .asGif()
            .load(R.drawable.capi_news)
            .into(ivNews)

        lifecycleScope.launch {
            val type = randomReportType()   // 1 or 2 (for now)

            val text = when (type) {
                1 -> ReportUtils.generateMinSeed(this@HomePageActivity)
                2 -> ReportUtils.generateBestSoldSummary(this@HomePageActivity)
                else -> "No news available"   // fallback to avoid crashes
            }

            tvNews.text = text
        }

    }


}

private fun randomReportType() = (1..2).random()