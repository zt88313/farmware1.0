package com.example.farmware

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.farmware.PrefsManager.setNetworkState

class ChooseModeActivity : AppCompatActivity() {


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_choose_mode)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        val btnOnline: Button = findViewById(R.id.btn_online)
        val btnOffline: Button = findViewById(R.id.btn_offline)

        btnOnline.setOnClickListener {
            setNetworkState(this, "online")
            //navigateToLoginActivity()//test go
            Toast
                .makeText(this, "Online mode not launched yet", Toast.LENGTH_SHORT)
                .show()
        }
        btnOffline.setOnClickListener {
            setNetworkState(this, "offline")
            navigateToLoginActivity()
        }

    }

    // Function to navigate to the second activity without sending data
    private fun navigateToLoginActivity() {
        // Create an Intent to start the second activity
        val intent = Intent(this, LoginActivity::class.java)

        // Start the second activity
        startActivity(intent)
    }

}