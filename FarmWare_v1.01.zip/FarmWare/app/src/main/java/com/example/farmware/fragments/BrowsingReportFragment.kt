package com.example.farmware.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import com.example.farmware.LocalDatabase
import com.example.farmware.R
import com.example.farmware.goReportChoosing
import com.example.farmware.offlinebase.daos.ProductDao
import com.example.farmware.offlinebase.daos.SeedDao
import com.example.farmware.offlinebase.daos.TradeHistoryItemDao
import kotlinx.coroutines.launch

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
//private const val ARG_PARAM1 = "param1"
//private const val ARG_PARAM2 = "param2"





/**
 * A simple [Fragment] subclass.
 * Use the [BrowsingReportFragment.newInstance] factory method to
 * create an instance of this fragment.
 */

class BrowsingReportFragment : Fragment() {
    private var itemId: Int = -1
    private lateinit var productDao: ProductDao
    private lateinit var seedDao: SeedDao
    private lateinit var tradeHistoryItemDao: TradeHistoryItemDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // get item_id (report type/number)
        itemId = arguments?.getInt("item_id") ?: return

        productDao = LocalDatabase
            .getDatabase(requireContext())
            .productDao()

        seedDao = LocalDatabase
            .getDatabase(requireContext())
            .seedDao()

        tradeHistoryItemDao = LocalDatabase
            .getDatabase(requireContext())
            .tradeHistoryItemDao()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_browsing_report, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //  find views
        val tvReportTitle   = view.findViewById<TextView>(R.id.tv_report_title)
        val tvReportContent = view.findViewById<TextView>(R.id.tv_report_content)
        val btnBack         = view.findViewById<ImageButton>(R.id.ibtn_back_report_browse)

        // wire up back button
        btnBack.setOnClickListener {
            goReportChoosing(requireContext())
        }

        // show the proper report
        when (itemId) {
            1 -> {
                tvReportTitle.text   = "Products storage status"
                var message1: String
                viewLifecycleOwner.lifecycleScope.launch {
                    //in a coroutine...
                    message1 = generateProductsStorageStatus()
                    tvReportContent.text = message1
                }
            }

            2 -> {
                tvReportTitle.text   = "Seeds low storage warning"
                var message2: String
                viewLifecycleOwner.lifecycleScope.launch {
                    //in a coroutine...
                    message2 = generateMinSeed()
                    tvReportContent.text = message2
                }
            }

            3 -> {
                tvReportTitle.text   = "Best sold item"
                var message3: String
                viewLifecycleOwner.lifecycleScope.launch {
                    //in a coroutine...
                    message3 = generateBestSoldSummary()
                    tvReportContent.text = message3
                }
            }
        }

    }


     suspend fun generateProductsStorageStatus(): String{
        val totalCount = productDao.getProductCount()
        val maxItems = productDao.getMaxQuantityItems()
        val itemsStr = maxItems.joinToString(", ") {
            "${it.productName} (${it.productQuantity})"
        }
        val verb = if (maxItems.size > 1) "are" else "is" //if multiple max item, use are
         return """
            Inventory Summary:
            - Total product types: $totalCount
            - Top quantity item${if (verb == "are") "s" else ""} $verb: $itemsStr
        """.trimIndent()
    }

    suspend fun generateMinSeed(): String{
        val minSeeds = seedDao.getSeedsWithLowestQuantity()
        val itemsStr = minSeeds.joinToString(", ") { "${it.seedName} (${it.seedQuantity})" }
        // decide "is or are"
        val verb = if (minSeeds.size > 1) "are" else "is"
        // return
        return """
            Inventory Summary:
            These seed${if (minSeeds.size > 1) "s" else ""} $verb at the lowest storage:
            $itemsStr
        """.trimIndent()
    }

    private suspend fun generateBestSoldSummary(): String {
        val bestItems = tradeHistoryItemDao.getBestSoldItemsWithName()
        val itemsStr = bestItems.joinToString("\n") { "- ${it.itemName} (money gain: ${"%.2f".format(it.revenue)})" }
        val verb = if (bestItems.size > 1) "are" else "is"

        return """
Trade Summary:
    Best‐selling item${if (bestItems.size > 1) "s" else ""} $verb:
$itemsStr
""".trimIndent()
    }

}

