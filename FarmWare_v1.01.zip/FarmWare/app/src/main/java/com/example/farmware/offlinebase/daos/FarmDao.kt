package com.example.farmware.offlinebase.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.farmware.offlinebase.entities.FarmEntity

@Dao
interface FarmDao {
    @Insert
    suspend fun insert(farm: FarmEntity): Long

    @Query("SELECT * FROM farm")
    suspend fun getAll(): List<FarmEntity>

    @Query("SELECT * FROM farm WHERE user_id = :userId")
    suspend fun getFarmsByUser(userId: Int): List<FarmEntity>

    @Query("SELECT * FROM farm WHERE farm_id = :id")
    suspend fun getFarmById(id: Int): FarmEntity?

    @Update
    suspend fun updateFarm(farm: FarmEntity)

    @Query("DELETE FROM farm WHERE farm_id = :id")
    suspend fun deleteById(id: Int)
}
