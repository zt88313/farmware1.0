// app/src/main/java/com/example/farmware/Utils.kt
package com.example.farmware

import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.net.Uri
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.farmware.HomePageActivity
import com.example.farmware.fragments.auth.ForgotPasswordFragment

const val MANAGER_EMAIL = "farmware@gmail.com"

//activity jump functions
fun jumpToHomePage(context: Context) {
    Intent(context, HomePageActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
    }.also(context::startActivity)
    if (context is LoginActivity) context.finish()
}

fun jumpToDatabaseBrowsing(context: Context) {
    Intent(context, DatabaseBrowsingActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
    }.also(context::startActivity)
}

fun jumpToDataform(context: Context, itemId: Int, fragmentType: String) {
    Intent(context, DataFormActivity::class.java).apply {
        putExtra("fragment_type", fragmentType)
        putExtra("item_id", itemId)
    }.also(context::startActivity)
}

fun navigateToDatabaseBrowsing(context: Context) {
    context.startActivity(Intent(context, DatabaseBrowsingActivity::class.java))
}

fun navigateToAddDataForm(context: Context) {
    Intent(context, DataFormActivity::class.java).apply {
        putExtra("fragment_type", "addData")
    }.also(context::startActivity)
}

fun navigateToFeedbackForm(context: Context) {
    Intent(context, DataFormActivity::class.java).apply {
        putExtra("fragment_type", "feedback")
    }.also(context::startActivity)
}

fun navigateToLoginActivity(context: Context) {
    Intent(context, LoginActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
    }.also(context::startActivity)
}

fun jumpToProfileEditingForm(context: Context) {
    Intent(context, DataFormActivity::class.java).apply {
        putExtra("fragment_type", "editProfile")
        putExtra("item_id", PrefsManager.getLoggedInUserId(context))
    }.also(context::startActivity)
}

fun goChooseMode(context: Context) {
    Intent(context, ChooseModeActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
    }.also(context::startActivity)
}


/**
 * Launches the report-selection screen.
 *
 * //@param context The Context (usually an Activity) from which to start.
 */

fun goReportChoosing(context: Context) {
    Intent(context, ReportChoosingActivity::class.java).apply {
        // clear any existing instance on top so tapping again won't stack duplicates
        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
    }.also { intent ->
        context.startActivity(intent)
    }
}
//activity jump functions


fun getFieldsForTable(tableName: String): List<String> = when (tableName.lowercase()) {
    "user"           -> listOf("user_name", "user_email", "user_password")
    "farm"           -> listOf("farm_name", "farm_info")
    "warehouse"      -> listOf("farm_id", "warehouse_name", "warehouse_capacity")
    "farming_field"  -> listOf("farm_id", "field_name", "field_type")

    "trader"         -> listOf("trader_name", "trader_type", "trader_email",
        "trader_contact", "trader_description")

    "trade_history", "trade history"  -> listOf("trader_id",
        "farm_id", "warehouse_id", "trade_date", "trade_type")

    "seed"           -> listOf("warehouse_id", "seed_name", "seed_unit", "seed_quantity")
    "product"        -> listOf("warehouse_id", "product_name", "product_unit", "product_quantity")

    "miscellaneous_item" -> listOf("warehouse_id", "miscellaneous_item_name",
        "miscellaneous_item_description", "miscellaneous_item_unit", "miscellaneous_item_quantity")

    "biochemical_item" -> listOf("warehouse_id", "biochemical_item_name",
        "biochemical_item_description", "biochemical_item_unit", "biochemical_item_quantity")

    "trade_history_item" -> listOf("trade_history_id",
        "item_type", "item_id", "quantity", "price")

    else              -> emptyList()
}


fun getCurrentDate(): String {
    return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        .format(Date())
}

// Simple XOR+Base64 encryption
fun encryptPassword(password: String, key: Char = 'K'): String {
    val xored = password.map { it.code.xor(key.code).toByte() }.toByteArray()
    return android.util.Base64.encodeToString(xored, android.util.Base64.NO_WRAP)
}


object PrefsManager {
    private const val PREFS = "app_prefs"
    private const val KEY_FP_COUNT = "forgot_pw_count"
    private const val KEY_FP_DATE  = "forgot_pw_date"

    fun setNetworkState(context: Context, state: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString("app_network_state", state).apply()
    }

    fun getNetworkState(context: Context): String {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("app_network_state", "offline") ?: "offline"
    }

    fun setSelectedTable(context: Context, tableName: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString("selected_table", tableName).apply()
    }

    fun getSelectedTable(context: Context): String {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("selected_table", "farm") ?: "farm"
    }

    fun setLoggedInUserId(context: Context, id: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putInt("logged_in_user_id", id).apply()
    }

    fun getLoggedInUserId(context: Context): Int {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt("logged_in_user_id", -1)
    }

    fun setRememberMeChecked(context: Context, checked: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean("remember_me_checked", checked).apply()
    }

    fun isRememberMeChecked(context: Context): Boolean {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean("remember_me_checked", false)
    }

    fun updateRememberedUserIfChanged(context: Context, username: String, password: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val savedUsername = prefs.getString("remembered_username", null)
        val savedPassword = prefs.getString("remembered_password", null)
        if (savedUsername != username || savedPassword != password) {
            prefs.edit()
                .putString("remembered_username", username)
                .putString("remembered_password", password)
                .apply()
        }
    }

    fun clearRememberedUser(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove("remembered_username")
            .remove("remembered_password")
            .apply()
    }

    fun getRememberedUser(context: Context): Pair<String?, String?> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString("remembered_username", null) to
                prefs.getString("remembered_password", null)
    }

    /** Returns how many times today the user has requested a password reset. */
    fun getForgotCount(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        if (prefs.getString(KEY_FP_DATE, "") != today) {
            prefs.edit()
                .putString(KEY_FP_DATE, today)
                .putInt(KEY_FP_COUNT, 0)
                .apply()
        }
        return prefs.getInt(KEY_FP_COUNT, 0)
    }

    /** Increments today’s Forgot‐Password request count by 1. */
    fun incrementForgotCount(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val count = prefs.getInt(KEY_FP_COUNT, 0) + 1
        prefs.edit().putInt(KEY_FP_COUNT, count).apply()
    }
}

/**
 * Launches an email intent to `to` with the given subject and body.
 */
fun sendForgotPasswordEmail(context: Context, to: String, subject: String, body: String) {
    val intent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("mailto:") // only email apps
        putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
        putExtra(Intent.EXTRA_SUBJECT, subject)
        putExtra(Intent.EXTRA_TEXT, body)
    }
    context.startActivity(Intent.createChooser(intent, "Send email via"))
}

fun AppCompatActivity.showLogoutConfirmation() {
    AlertDialog.Builder(this)
        .setTitle("Confirm Logout")
        .setMessage("Are you sure you want to log out?")
        .setPositiveButton("Logout") { _, _ ->
            // existing helper in Utils.kt or wherever you put it
            logout(this)
        }
        .setNegativeButton("Cancel", null)
        .show()
}
fun logout(context: Context) {
    // clear login‐related prefs
    PrefsManager.setLoggedInUserId(context, -1)

    // navigate back to LoginActivity as a fresh task
    navigateToLoginActivity(context)
}


enum class TableType(val label: String) {
    USER("User"),
    FARM("Farm"),
    WAREHOUSE("Warehouse"),
    FARMING_FIELD("Farming Field"),
    TRADER("Trader"),
    TRADE_HISTORY("Trade History"),
    SEED("Seed"),
    PRODUCT("Product"),
    MISCELLANEOUS_ITEM("Miscellaneous Item"),
    BIOCHEMICAL_ITEM("Biochemical Item"),
    TRADE_HISTORY_ITEM("Trade History Item");

    companion object {
        fun labels(): List<String> = values().map { it.label }
    }
}


enum class FeedbackMessage(val text: String) {
    THANK_YOU    ("Thank you for using Farmware!"),
    VERSION_INFO ("Farmware version 0.25 — developing report feature."),
    CONTACT_US   ("Need help? Contact us at"),
    CONTACT_EMAIL("farmware@gmail.com")
}


object ReportUtils {
    suspend fun generateMinSeed(context: Context): String {
        val dao = LocalDatabase.getDatabase(context).seedDao()
        val minSeeds = dao.getSeedsWithLowestQuantity()
        val items = minSeeds.joinToString(", ") { "${it.seedName} (${it.seedQuantity})" }
        val v = if (minSeeds.size>1) "are" else "is"
        return "Seeds $v low: $items"
    }

    suspend fun generateBestSoldSummary(context: Context): String {
        val dao = LocalDatabase.getDatabase(context).tradeHistoryItemDao()
        val best = dao.getBestSoldItemsWithName()
        val item = best.maxByOrNull { it.revenue } ?: return "No sales yet"
        return "${item.itemName} sells best now, consider producing more!"
    }
}
