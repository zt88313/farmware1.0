package com.example.farmware.fragments.auth

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.farmware.LocalDatabase
import com.example.farmware.LoginActivity
import com.example.farmware.databinding.FragmentSignupBinding
import com.example.farmware.offlinebase.entities.UserEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SignupFragment : Fragment() {
    private var _binding: FragmentSignupBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = FragmentSignupBinding.inflate(inflater, container, false).also {
        _binding = it
    }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnSignup.setOnClickListener {
            val username = binding.editTextUsername.text.toString().trim()
            val email    = binding.editTextEmail.text.toString().trim()
            val pass     = binding.editTextPassword.text.toString()
            val confirm  = binding.editTextConfirmPassword.text.toString()

            when {
                username.isEmpty() || email.isEmpty() || pass.isEmpty() || confirm.isEmpty() ->
                    Toast.makeText(requireContext(), "All fields are required", Toast.LENGTH_SHORT).show()
                pass != confirm ->
                    Toast.makeText(requireContext(), "Passwords do not match", Toast.LENGTH_SHORT).show()
                else -> lifecycleScope.launch {
                    val dao = LocalDatabase.getDatabase(requireContext()).userDao()

                    // run the lookup on IO
                    val exists = withContext(Dispatchers.IO) {
                        dao.getUserByUsername(username)
                    }

                    if (exists != null) {
                        // back on Main automatically
                        Toast.makeText(requireContext(), "Username already taken", Toast.LENGTH_SHORT).show()
                    } else {
                        val hash = hashPassword(pass)
                        val newUser = UserEntity(
                            userName     = username,
                            userEmail    = email,
                            userPassword = hash
                        )

                        // run the insert on IO
                        withContext(Dispatchers.IO) {
                            dao.insert(newUser)
                        }

                        Toast.makeText(requireContext(), "Sign-up successful!", Toast.LENGTH_SHORT).show()
                        // navigate back to login
                        parentFragmentManager.popBackStack()
                    }
                }
            }
        }

        binding.tvLogin.setOnClickListener {
            (activity as? LoginActivity)?.showLoginFragment()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun hashPassword(password: String): String =
        password.reversed()  // same temporary hash as LoginFragment :contentReference[oaicite:1]{index=1}
}
