// DatabaseBrowsingActivity.kt
package com.example.farmware

import android.os.Bundle
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.farmware.offlinebase.entities.FarmingFieldEntity
import com.example.farmware.offlinebase.entities.WarehouseEntity
import com.example.farmware.offlinebase.entities.FarmEntity
import kotlinx.coroutines.launch

class DatabaseBrowsingActivity : AppCompatActivity() {
    private lateinit var rvAdapter: DataCardAdapter
    private val dataItems = mutableListOf<DataItem>()
    private lateinit var db: LocalDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_database_browsing)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val s = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(s.left, s.top, s.right, s.bottom)
            insets
        }

        db = LocalDatabase.getDatabase(this)
        rvAdapter = DataCardAdapter(dataItems)
        findViewById<RecyclerView>(R.id.rv_datacards).apply {
            layoutManager = LinearLayoutManager(this@DatabaseBrowsingActivity)
            adapter = rvAdapter
        }

        rvAdapter.onDeleteClicked = { pos ->
            AlertDialog.Builder(this)
                .setTitle("Confirm Delete")
                .setMessage("Are you sure you want to delete this item?")
                .setPositiveButton("Delete") { _, _ ->
                    lifecycleScope.launch {
                        // remove from DB
                        val key = PrefsManager.getSelectedTable(this@DatabaseBrowsingActivity)
                        val sel = key.lowercase().replace(' ', '_')
                        val item = dataItems[pos]
                        when (sel) {
                            "farm"          -> db.farmDao().deleteById(item.id)
                            "warehouse"     -> db.warehouseDao().deleteById(item.id)
                            "farming_field" -> db.farmingFieldDao().deleteById(item.id)
                            "trader"        -> db.traderDao().deleteById(item.id)
                            "trade_history" -> db.tradeHistoryDao().deleteById(item.id)
                            "seed"           -> db.seedDao().deleteById(item.id)
                            "product" -> db.productDao().deleteById(item.id)
                            "miscellaneous_item" -> db.miscellaneousItemDao().deleteById(item.id)
                            "biochemical_item" -> db.biochemicalItemDao().deleteById(item.id)
                            "trade_history_item" -> db.tradeHistoryItemDao().deleteById(item.id)

                        }
                        // reload same table
                        loadCurrentTable()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Spinner setup (exclude "User")
        val spin = findViewById<Spinner>(R.id.spin_choosetable)
        val labels = TableType.labels().filter { it != "User" }
        spin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        restoreSpinnerSelection(spin, labels)
        spin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>, view: android.view.View?, pos: Int, id: Long
            ) {
                val raw = parent.getItemAtPosition(pos).toString()
                PrefsManager.setSelectedTable(this@DatabaseBrowsingActivity, raw)
                loadCurrentTable()
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        findViewById<Button>(R.id.btn_addnew).setOnClickListener {
            navigateToAddDataForm(this)
        }
        findViewById<ImageButton>(R.id.ibtn_back_db_brow).setOnClickListener {
            jumpToHomePage(this)
        }

        // initial load
        loadCurrentTable()
    }

    private fun restoreSpinnerSelection(spinner: Spinner, options: List<String>) {
        val savedKey = PrefsManager.getSelectedTable(this)
        val normKey  = savedKey.lowercase().replace(' ', '_')
        val idx = options.indexOfFirst { it.lowercase().replace(' ', '_') == normKey }
        if (idx >= 0) spinner.setSelection(idx)
    }


    private fun loadCurrentTable() = lifecycleScope.launch {
        val raw    = PrefsManager.getSelectedTable(this@DatabaseBrowsingActivity)
        val key    = raw.lowercase().replace(' ', '_')
        val userId = PrefsManager.getLoggedInUserId(this@DatabaseBrowsingActivity)

        val uiItems = when (key) {
            "farm" -> db.farmDao()
                .getFarmsByUser(userId)
                .map { DataItem(it.farmId, it.farmName, it.farmInfo) }

            "warehouse" -> db.warehouseDao()
                .getWarehousesByUser(userId)
                .map {
                    DataItem(
                        it.warehouseId,
                        it.warehouseName,
                        "Cap: ${it.warehouseCapacity}"
                    )
                }

            "farming_field" -> db.farmingFieldDao()
                .getFieldsByUser(userId)
                .map {
                    DataItem(
                        it.fieldId,
                        it.fieldName,
                        it.fieldType
                    )
                }
            "trader" -> db.traderDao().getAll().map {
                // UPDATED: use TraderEntity’s camelCase fields
                DataItem(
                    it.traderId,
                    it.traderName,
                    "Type: ${it.traderType}"
                )
            }

            "trade_history" -> db.tradeHistoryDao().getAll().map {
                DataItem(
                    it.tradeHistoryId,
                    it.tradeDate,
                    "Type: ${it.tradeType}"
                )
            }

            "seed" -> db.seedDao().getAll().map {
                // show ID, name and quantity/unit
                DataItem(
                    it.seedId,
                    it.seedName,
                    "Qty: ${it.seedQuantity} ${it.seedUnit}"
                )
            }

            "product" -> db.productDao().getAll().map {
                // show ID, name and quantity/unit
                DataItem(
                    it.productId,
                    it.productName,
                    "Qty: ${it.productQuantity} ${it.productUnit}"
                )
            }
            "miscellaneous_item" -> db.miscellaneousItemDao().getAll().map {
                // show ID, name and quantity/unit
                DataItem(
                    it.miscellaneousItemId,
                    it.itemName,
                    "Qty: ${it.itemQuantity} ${it.itemUnit}"
                )
            }
            "biochemical_item" -> db.biochemicalItemDao().getAll().map {
                DataItem(
                    it.biochemicalItemId,
                    it.itemName,
                    "Qty: ${it.itemQuantity} ${it.itemUnit}"
                )
            }
            "trade_history_item" -> db.tradeHistoryItemDao().getAll().map {
                DataItem(
                    it.tradeHistoryItemId,
                    "Type: ${it.itemType}, ID: ${it.itemId}",
                    "Qty: ${it.quantity}, Price: ${it.price}"
                )
            }

            else -> emptyList()
        }

        rvAdapter.updateData(uiItems.toMutableList())
    }


}
